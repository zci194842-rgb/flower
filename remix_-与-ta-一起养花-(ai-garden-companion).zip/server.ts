import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Lazy-initialized Gemini Client with telemetry headers
let aiClient: GoogleGenAI | null = null;
function getAI() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is required");
    }
    aiClient = new GoogleGenAI({ 
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// API Routes
app.post("/api/dialogue", async (req, res) => {
  try {
    const { character, flower, state, action } = req.body;
    const ai = getAI();
    const model = "gemini-3.5-flash";

    const systemInstruction = `
      你正在扮演一个AI角色，该角色正在和用户一起养花。
      当前角色信息:
      姓名: ${character.name}
      性格: ${character.personality}
      描述: ${character.description}

      当前花卉信息:
      品种: ${flower.type}
      状态: ${state.flowerStage}
      健康值: ${state.flowerHealth}/100
      用户恨意值: ${state.hatredPoints || 0} (越高代表对方越生气，因为用户玩忽职守)

      环境状态:
      水分: ${state.waterLevel}/100
      土质: ${state.soilQuality}/100
      害虫: ${state.pestLevel}/100
      杂草: ${state.weedsLevel}/100

      指令:
      1. 根据角色的性格和当前花的状况，生成一段1-3句的对话。
      2. 如果用户刚刚执行了某个动作(action: ${action}), 请对此做出反馈。
      3. 如果用户很久没来 (lastActiveTime 距离现在很久), 请表现出相应的态度（如果超过10天，表现出失望和恨意）。
      4. 保持角色代入感，不要直接说出状态数值，要通过语气和具体的描述来体现。
      5. 使用中文。
    `;

    const response = await ai.models.generateContent({
      model,
      contents: "请根据当前情况跟我说句话吧。",
      config: {
        systemInstruction,
        temperature: 0.8,
      },
    });

    res.json({ text: response.text || "……（默默地看着花）" });
  } catch (error: any) {
    console.error("Gemini API Error in /api/dialogue:", error);
    res.status(500).json({ error: error.message || "Failed to generate dialogue" });
  }
});

app.post("/api/letter", async (req, res) => {
  try {
    const { writerCharacter, flowerNames, isJealous, targetName, userCardMessage } = req.body;
    const ai = getAI();
    const model = "gemini-3.5-flash";

    const systemInstruction = `
      你正在扮演一个AI角色: ${writerCharacter.name}。
      性格: ${writerCharacter.personality}
      
      情境:
      用户采摘了你们共同培育的 "${flowerNames}"。
      ${userCardMessage ? `用户在送礼时附带了一张贺卡，上面写着: "${userCardMessage}"` : ""}
      
      任务:
      写一封简短的回信给用户（100字左右）。回信中可以提到用户的贺卡内容（如果有的话）。
      
      分类处理:
      1. 正常感谢 (isJealous: false):
         用户直接把花送给了你。请根据你的性格表达欣喜、感谢和对这段共同回忆的珍惜。
      
      2. 吃醋与责备 (isJealous: true):
         用户竟然背着你，把你们辛苦养大的这些花送给了 "${targetName}"！
         你现在非常生气、委屈或者感到被背叛。请根据你的角色性格，写一封质问、责备或者流露伤感的信。你必须提到你发现了这些花被送给了 ${targetName}，并表达你的不满。哪怕用户在贺卡里说了甜言蜜语，你也会觉得那很虚伪。
      
      请用中文书写这封信，语气要极其符合角色设定。
    `;

    const response = await ai.models.generateContent({
      model,
      contents: "请写这封回信。",
      config: {
        systemInstruction,
        temperature: 0.9,
      },
    });

    res.json({ text: response.text || "谢谢你的花。" });
  } catch (error: any) {
    console.error("Gemini API Error in /api/letter:", error);
    res.status(500).json({ error: error.message || "Failed to generate letter" });
  }
});

// Vite / static file serving integration
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
