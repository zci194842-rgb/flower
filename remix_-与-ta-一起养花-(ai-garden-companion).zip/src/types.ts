/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type FlowerType = '竹子' | '梅花' | '百合' | '菊花' | '薄荷' | '向日葵' | '紫丁香' | '月季' | '玫瑰' | '剑兰' | '芍药' | '荷花' | '郁金香' | '马蹄莲';
export type PotStyle = 'terracotta' | 'ceramic' | 'marble';

export interface PotData {
  id: PotStyle;
  name: string;
  image: string;
  color: string;
  borderColor: string;
}

export interface FlowerData {
  type: FlowerType;
  name: string;
  image: string;
  description: string;
  language: string;
}

export interface CharacterData {
  id: string;
  name: string;
  avatar: string;
  personality: string;
  description: string;
}

export interface GameState {
  flowerType: FlowerType | null;
  characterId: string | null;
  potStyle: PotStyle | null;
  startTime: number; // timestamp
  lastActiveTime: number; // timestamp
  flowerHealth: number; // 0-100
  flowerStage: 'seed' | 'harvested' | 'sprout' | 'growing' | 'blooming' | 'withered';
  hatredPoints: number;
  waterLevel: number;
  soilQuality: number;
  pestLevel: number;
  weedsLevel: number;
  history: GameEvent[];
  bouquets: FlowerType[]; // Collected flowers
  letters: Letter[];
  unlockedFlowers?: FlowerType[]; // Flowers grown and unlocked in book
  completedPremiumBouquets?: string[]; // IDs of crafted premium bouquets
  claimedBookReward?: boolean; // Whether the 200 items (响石) + avatar frame are claimed
  walletStone?: number; // Stone count ("响石"), defaults to 0
  unlockedFrames?: string[]; // Allowed/unlocked avatar frames
}

export interface Letter {
  id: string;
  fromId: string;
  fromName: string;
  content: string;
  time: number;
  isJealous: boolean;
}

export interface GameEvent {
  time: number;
  type: 'water' | 'soil' | 'pest' | 'weed' | 'nutrient' | 'ai_visit' | 'wither' | 'harvest' | 'gift';
  description: string;
}

export const POTS: PotData[] = [
  { id: 'terracotta', name: '经典陶器', image: '🏺', color: '#eaddca', borderColor: '#c5b399' },
  { id: 'ceramic', name: '青瓦瓷盆', image: '🍶', color: '#e0f2f1', borderColor: '#b2dfdb' },
  { id: 'marble', name: '墨玉石盆', image: '🌑', color: '#455a64', borderColor: '#263238' },
];

export const FLOWERS: FlowerData[] = [
  { type: '竹子', name: '翠竹', image: '🎋', description: '宁折不弯，岁寒不凋。象征着坚韧与虚怀若谷。', language: '坚韧不拔、步步高升、虚心大度' },
  { type: '梅花', name: '寒梅', image: '🌸', description: '墙角数枝梅，凌寒独自开。象征着高洁与孤傲。', language: '坚强、高雅、不畏艰难、傲骨迎春' },
  { type: '百合', name: '白百合', image: '/avatars/baihe.png', description: '百年好合，纯洁高雅。象征着圣洁与庄严。', language: '纯洁无瑕、百年好合、伟大的爱、杰出代表' },
  { type: '菊花', name: '秋菊', image: '🌻', description: '采菊东篱下，悠然见南山。象征着隐逸与长寿。', language: '高洁长寿、隐逸淡泊、清净真挚' },
  { type: '薄荷', name: '薄荷', image: '🌿', description: '清凉宜人，生机勃勃。象征着清新与希望。', language: '愿与你再次相逢、美德、清新与希望' },
  { type: '向日葵', name: '向日葵', image: '☀️', description: '心向阳光，永不言弃。象征着忠诚与热情。', language: '沉默的爱、充满阳光、赤诚的忠诚与爱慕' },
  { type: '紫丁香', name: '紫丁香', image: '💐', description: '初恋的忧愁，纯洁的初恋。象征着美丽与忧伤。', language: '初恋的萌芽、纯洁无暇的回忆、光荣与美丽' },
  { type: '月季', name: '月季', image: '🌺', description: '月月常开，色彩斑斓。象征着持久与热情。', language: '持之以恒的爱、心怀期待、幸福美满' },
  { type: '玫瑰', name: '玫瑰', image: '🌹', description: '浓情似火，真挚之爱。象征着浪漫与激情。', language: '热烈真挚的爱、真诚相伴、至死不渝' },
  { type: '剑兰', name: '剑兰', image: '💮', description: '叶似长剑，花如钟铃。象征着步步高升和坚贞。', language: '高尚、坚强、步步高升、福禄、用心' },
  { type: '芍药', name: '芍药', image: '🏵️', description: '情之所钟，绝代风华。象征着思念、惜别与依依不舍。', language: '依依不舍、难舍难分、美丽动人、情有独钟' },
  { type: '荷花', name: '荷花', image: '🪷', description: '出淤泥而不染，濯清涟而不妖。象征着圣洁与纯真。', language: '清白、坚贞纯洁、信仰、高尚君子之风' },
  { type: '郁金香', name: '郁金香', image: '🌷', description: '典雅高贵，仪态万千。象征着博爱、体贴和永恒的祝福。', language: '爱、慈善、名誉、美丽、热恋与祝福' },
  { type: '马蹄莲', name: '马蹄莲', image: '🪻', description: '亭亭玉立，素雅大方。自有一股清新圣洁的美态。', language: '忠贞不渝、永结同心、纯洁无瑕的爱' },
];

export const CHARACTERS: CharacterData[] = [
  { 
    id: 'naruto', 
    name: '漩涡鸣人', 
    avatar: '/avatars/naruto.png', 
    personality: '极其阳光积极，精力充沛，永不言弃。',
    description: '他会用火影般的毅力陪你养花，即使你偶尔偷懒，他也会大声鼓励你“这也是一种修行”！' 
  },
  { 
    id: 'ran', 
    name: '毛利兰', 
    avatar: '/avatars/ran.png', 
    personality: '温柔体贴，极富正义感，但对约定非常看重。',
    description: '她会细心记录每一次浇水。如果你失约太久，她会像等待那个总是消失的新一一样感到极度难过。' 
  },
  { 
    id: 'kurapika', 
    name: '酷拉皮卡', 
    avatar: '/avatars/3(1).png', 
    personality: '沉稳冷静，博学睿智，同时也带有一抹忧郁。',
    description: '他会对养花的每一个细节进行深入研究。他的世界充满了规则，缺席对这朵花来说是不可原谅的背叛。' 
  }
];

export interface PremiumBouquet {
  id: string;
  name: string;
  emoji: string;
  formula: { [key in FlowerType]?: number };
  description: string;
}

export const PREMIUM_BOUQUETS: PremiumBouquet[] = [
  {
    id: 'b1',
    name: '【暂未取名】',
    emoji: '💠🧚',
    formula: { '百合': 10, '玫瑰': 5, '月季': 8, '剑兰': 1 },
    description: '永恒誓言的神秘交织。结合了百合的清雅、玫瑰的热烈、月季的持之以恒，以及剑兰的坚贞。'
  },
  {
    id: 'b2',
    name: '紫雾幽香',
    emoji: '🌌🔮',
    formula: { '紫丁香': 10, '芍药': 3, '荷花': 1 },
    description: '幽夜静谧处的紫色迷雾。丁香的忧郁初恋、生机盎然的芍药以及高洁脱俗的荷花，幽香绵长。'
  },
  {
    id: 'b3',
    name: '炙热心弦',
    emoji: '💞🔥',
    formula: { '玫瑰': 10, '芍药': 2, '剑兰': 2 },
    description: '心跳瞬间的情感共鸣。如火般炽热的玫瑰，伴着依依不舍的芍药，刻下剑兰长剑守护的坚毅誓言。'
  },
  {
    id: 'b4',
    name: '馥郁清晨',
    emoji: '🌅🌤️',
    formula: { '百合': 8, '月季': 4, '郁金香': 6 },
    description: '清晨露珠折射出的温暖花香。高贵圣洁的百合与缤纷如期绽放的月季，织入郁金香的典雅欢欣。'
  },
  {
    id: 'b5',
    name: '幽谷回响',
    emoji: '⛲🪽',
    formula: { '玫瑰': 8, '紫丁香': 4, '马蹄莲': 6 },
    description: '遥远山野幽谷中传来的爱意。山泉边的马蹄莲静谧绽放，携手浪漫玫瑰与梦幻丁香的轻声应答。'
  },
  {
    id: 'b6',
    name: '浅夏微风',
    emoji: '🍃👒',
    formula: { '月季': 8, '马蹄莲': 3, '剑兰': 4 },
    description: '初夏拂过发梢的清甜晚风。挺拔青翠的剑兰、素雅的马蹄莲和缤纷常艳的月季，谱写夏日低吟。'
  }
];
