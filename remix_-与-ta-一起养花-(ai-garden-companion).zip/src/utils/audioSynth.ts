/**
 * GardenAudioSynth - A professional Web Audio API synthesizer for the Flower Garden App.
 * Programmatically generates responsive sound effects for tools and seasonal environments
 * WITHOUT requiring external network assets, preventing CORS issues or load delays.
 */

class GardenAudioSynth {
  private ctx: AudioContext | null = null;
  private ambientNodes: {
    windGain?: GainNode;
    windOsc?: OscillatorNode;
    breezeFilter?: BiquadFilterNode;
    cricketsGain?: GainNode;
    cricketsTimer?: NodeJS.Timeout;
    cracklesTimer?: NodeJS.Timeout;
    noiseSource?: AudioBufferSourceNode;
  } = {};
  
  private currentSeason: 'spring' | 'summer' | 'autumn' | 'winter' = 'spring';
  private currentWeather: 'sunny' | 'rainy' = 'sunny';
  private isMuted: boolean = true;

  constructor() {
    // AudioContext will be initialized on user interaction
  }

  private initContext() {
    if (!this.ctx) {
      // @ts-ignore - Support standard and older webkit browsers
      const AudioCtxFn = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxFn) {
        this.ctx = new AudioCtxFn();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(err => console.log("Failed to resume AudioContext:", err));
    }
    return this.ctx;
  }

  /**
   * Play sound effects when tools are clicked
   */
  public playToolSound(toolType: 'water' | 'soil' | 'pest' | 'weed' | 'nutrient') {
    const ctx = this.initContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;

      switch (toolType) {
        case 'soil': {
          // 翻土: Low-pitched granular earth friction (bandpassed noise rumble)
          const duration = 0.35;
          const bufferSize = ctx.sampleRate * duration;
          const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }

          const noise = ctx.createBufferSource();
          noise.buffer = buffer;

          const filter = ctx.createBiquadFilter();
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(240, now);
          filter.frequency.exponentialRampToValueAtTime(80, now + duration);

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0, now);
          gain.gain.linearRampToValueAtTime(0.25, now + 0.05);
          gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

          noise.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);
          noise.start(now);
          break;
        }

        case 'water': {
          // 浇水: Cascade of crystal water drops (bubbly droplets)
          [0, 0.07, 0.14, 0.21].forEach((delay, index) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            
            osc.type = 'sine';
            const startFreq = 220 + Math.random() * 50 + index * 40;
            const endFreq = 750 + Math.random() * 100 + index * 80;

            osc.frequency.setValueAtTime(startFreq, now + delay);
            osc.frequency.exponentialRampToValueAtTime(endFreq, now + delay + 0.08);

            gain.gain.setValueAtTime(0, now + delay);
            gain.gain.linearRampToValueAtTime(0.15, now + delay + 0.01);
            gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.09);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + delay);
            osc.stop(now + delay + 0.12);
          });
          break;
        }

        case 'pest': {
          // 除虫: High-frequency aerosol garden spray hiss
          const duration = 0.4;
          const bufferSize = ctx.sampleRate * duration;
          const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }

          const noise = ctx.createBufferSource();
          noise.buffer = buffer;

          const filter = ctx.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(4500, now);
          filter.frequency.linearRampToValueAtTime(2500, now + duration);
          filter.Q.setValueAtTime(4, now);

          const gain = ctx.createGain();
          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(0.18, now + 0.04);
          gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

          noise.connect(filter);
          filter.connect(gain);
          gain.connect(ctx.destination);
          noise.start(now);
          break;
        }

        case 'weed': {
          // 除草: Snapping weed stalk (sharp low click + tearing dry friction)
          const osc = ctx.createOscillator();
          const gainOsc = ctx.createGain();
          
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(140, now);
          osc.frequency.exponentialRampToValueAtTime(30, now + 0.06);

          gainOsc.gain.setValueAtTime(0, now);
          gainOsc.gain.linearRampToValueAtTime(0.3, now + 0.01);
          gainOsc.gain.exponentialRampToValueAtTime(0.001, now + 0.07);

          osc.connect(gainOsc);
          gainOsc.connect(ctx.destination);
          osc.start(now);
          osc.stop(now + 0.08);

          // Weed tear rasp
          const frictionDuration = 0.18;
          const bufferSize = ctx.sampleRate * frictionDuration;
          const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
          const data = buffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
          }

          const noise = ctx.createBufferSource();
          noise.buffer = buffer;

          const filter = ctx.createBiquadFilter();
          filter.type = 'bandpass';
          filter.frequency.setValueAtTime(700, now);
          filter.Q.setValueAtTime(6, now);

          const gainNoise = ctx.createGain();
          gainNoise.gain.setValueAtTime(0, now);
          gainNoise.gain.linearRampToValueAtTime(0.12, now + 0.02);
          gainNoise.gain.exponentialRampToValueAtTime(0.001, now + frictionDuration);

          noise.connect(filter);
          filter.connect(gainNoise);
          gainNoise.connect(ctx.destination);
          noise.start(now);
          break;
        }

        case 'nutrient': {
          // 施肥/瓶: Celestial C-Major Pentatonic cascade sweeps (glittery magic sparkle)
          const pentatonic = [523.25, 587.33, 659.25, 783.99, 880.00, 1046.50, 1174.66]; // C5, D5, E5, G5, A5, C6, D6
          pentatonic.forEach((freq, idx) => {
            const delay = idx * 0.05;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now + delay);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.05, now + delay + 0.35);

            gain.gain.setValueAtTime(0, now + delay);
            gain.gain.linearRampToValueAtTime(0.09, now + delay + 0.015);
            gain.gain.exponentialRampToValueAtTime(0.001, now + delay + 0.45);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + delay);
            osc.stop(now + delay + 0.5);
          });
          break;
        }
      }
    } catch (e) {
      console.warn("Error playing tool sound synthesized:", e);
    }
  }

  /**
   * Sound effect when button, tab or item is general clicked
   */
  public playClickSound() {
    const ctx = this.initContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, now);
      osc.frequency.exponentialRampToValueAtTime(300, now + 0.08);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.07, now + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.09);
    } catch {}
  }

  /**
   * Sound effect when a flower successfully blooms or achieves harvest!
   */
  public playBloomFanfare() {
    const ctx = this.initContext();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      const chords = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      
      chords.forEach((baseFreq, i) => {
        // Main notes with staggering arpeggio feel
        [0, 0.12].forEach((offset) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          
          osc.type = 'sine';
          osc.frequency.setValueAtTime(baseFreq, now + offset + i * 0.06);
          osc.frequency.setValueAtTime(baseFreq * 2, now + offset + i * 0.06 + 0.15);

          gain.gain.setValueAtTime(0, now + offset + i * 0.06);
          gain.gain.linearRampToValueAtTime(0.08, now + offset + i * 0.06 + 0.03);
          gain.gain.exponentialRampToValueAtTime(0.001, now + offset + i * 0.06 + 0.4);

          osc.connect(gain);
          gain.connect(ctx.destination);
          
          osc.start(now + offset + i * 0.06);
          osc.stop(now + offset + i * 0.06 + 0.5);
        });
      });
    } catch {}
  }

  /**
   * Update the background ambient sound loop generator based on season and weather status
   */
  public updateAmbient(season: 'spring' | 'summer' | 'autumn' | 'winter', weather: 'sunny' | 'rainy', isMuted: boolean) {
    this.currentSeason = season;
    this.currentWeather = weather;
    this.isMuted = isMuted;

    if (isMuted) {
      this.stopAmbientEngine();
      return;
    }

    const ctx = this.initContext();
    if (!ctx) return;

    // Start or maintain ambient generator nodes
    this.startAmbientEngine();
  }

  private startAmbientEngine() {
    const ctx = this.ctx;
    if (!ctx) return;

    // 1. Ensure basic wind/breeze generation context is set up
    if (!this.ambientNodes.windGain) {
      try {
        const now = ctx.currentTime;
        
        // Setup brown/pink-like noise filtered generator to simulate sweeping air/wind
        const bufferSize = ctx.sampleRate * 2; // 2 seconds loop
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        
        // Generate soft white noise to build customizable breeze
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.loop = true;

        const filter = ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, now);
        
        const gain = ctx.createGain();
        gain.gain.setValueAtTime(0.05, now);

        source.connect(filter);
        filter.connect(gain);
        gain.connect(ctx.destination);
        source.start(now);

        this.ambientNodes.noiseSource = source;
        this.ambientNodes.breezeFilter = filter;
        this.ambientNodes.windGain = gain;

        // Auto breeze sweep modulator
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(0.12, now); // Sweet slow breeze cycle every 8 seconds

        const oscGain = ctx.createGain();
        oscGain.gain.setValueAtTime(150, now); // swept frequency bounds

        osc.connect(oscGain);
        // Connect to Filter's frequency parameter directly
        oscGain.connect(filter.frequency);
        osc.start(now);
        this.ambientNodes.windOsc = osc;
      } catch (err) {
        console.warn("Unable to start synthesized natural air noise source:", err);
      }
    }

    // Stop current season timers
    if (this.ambientNodes.cricketsTimer) {
      clearInterval(this.ambientNodes.cricketsTimer);
      this.ambientNodes.cricketsTimer = undefined;
    }
    if (this.ambientNodes.cracklesTimer) {
      clearInterval(this.ambientNodes.cracklesTimer);
      this.ambientNodes.cracklesTimer = undefined;
    }

    // Apply season filter characteristics
    const filter = this.ambientNodes.breezeFilter;
    const gainNode = this.ambientNodes.windGain;
    if (gainNode && filter) {
      const now = ctx.currentTime;
      
      // Rainy weather increases ambient dark rumbling wind slightly
      const targetVolume = this.currentWeather === 'rainy' ? 0.08 : 0.035;
      gainNode.gain.cancelScheduledValues(now);
      gainNode.gain.linearRampToValueAtTime(targetVolume, now + 1.0);

      if (this.currentSeason === 'spring') {
        // Gentle warm spring: lowpass at around 400Hz
        filter.type = 'lowpass';
        this.startSpringBirdChirper();
      } else if (this.currentSeason === 'summer') {
        // Buzzing summer: lowpass at around 350Hz, launch active cicadas chirping!
        filter.type = 'lowpass';
        this.startSummerCicadas();
      } else if (this.currentSeason === 'autumn') {
        // Crisp autumn: bandpass for dryer, rustly rustling leaves feel
        filter.type = 'bandpass';
        this.startAutumnCrickets();
      } else if (this.currentSeason === 'winter') {
        // Cold winter whistling wind: highpass filter for hollow howl
        filter.type = 'highpass';
        this.startWinterCozyCrackles();
      }
    }
  }

  private stopAmbientEngine() {
    if (this.ambientNodes.cricketsTimer) {
      clearInterval(this.ambientNodes.cricketsTimer);
      this.ambientNodes.cricketsTimer = undefined;
    }
    if (this.ambientNodes.cracklesTimer) {
      clearInterval(this.ambientNodes.cracklesTimer);
      this.ambientNodes.cracklesTimer = undefined;
    }

    // Stop background noise nodes
    if (this.ambientNodes.noiseSource) {
      try { this.ambientNodes.noiseSource.stop(); } catch {}
      this.ambientNodes.noiseSource = undefined;
    }
    if (this.ambientNodes.windOsc) {
      try { this.ambientNodes.windOsc.stop(); } catch {}
      this.ambientNodes.windOsc = undefined;
    }
    this.ambientNodes.windGain = undefined;
    this.ambientNodes.breezeFilter = undefined;
  }

  // SPRING: Synthesize sweet small random birds chirps periodically
  private startSpringBirdChirper() {
    const ctx = this.ctx;
    if (!ctx) return;

    const playBirdSound = () => {
      if (this.isMuted || this.currentSeason !== 'spring') return;
      const now = ctx.currentTime;
      const count = 2 + Math.floor(Math.random() * 3); // 2-4 sweet micro chirps
      
      let baseDelay = 0;
      for (let i = 0; i < count; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        
        const centerFreq = 3000 + Math.random() * 800;
        osc.frequency.setValueAtTime(centerFreq, now + baseDelay);
        // sweep pitch up quickly
        osc.frequency.exponentialRampToValueAtTime(centerFreq + 600, now + baseDelay + 0.05);

        gain.gain.setValueAtTime(0, now + baseDelay);
        gain.gain.linearRampToValueAtTime(0.04, now + baseDelay + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, now + baseDelay + 0.06);

        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now + baseDelay);
        osc.stop(now + baseDelay + 0.08);
        baseDelay += 0.07 + Math.random() * 0.05;
      }
    };

    // Cycle every 4-8 seconds
    const loop = () => {
      playBirdSound();
      const nextDelay = 4000 + Math.random() * 4000;
      this.ambientNodes.cricketsTimer = setTimeout(loop, nextDelay);
    };
    this.ambientNodes.cricketsTimer = setTimeout(loop, 2000);
  }

  // SUMMER: Synthesize warm, retro-vibes rhythmic pulsing cicadas ("shhh-vvv, shhh-vvv")
  private startSummerCicadas() {
    const ctx = this.ctx;
    if (!ctx) return;

    const playCicadaPulse = () => {
      if (this.isMuted || this.currentSeason !== 'summer') return;
      const now = ctx.currentTime;
      const duration = 1.2 + Math.random() * 0.8; // pulsing period
      
      // Oscillator 5000Hz modulated in amplitude
      const osc = ctx.createOscillator();
      const modulator = ctx.createOscillator();
      const modGain = ctx.createGain();
      const mainGain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(4200, now);

      // Modulate amplitude around 20Hz for vibrating insect wings
      modulator.type = 'sine';
      modulator.frequency.setValueAtTime(22, now);
      
      modGain.gain.setValueAtTime(0.5, now);
      
      mainGain.gain.setValueAtTime(0, now);
      mainGain.gain.linearRampToValueAtTime(0.025, now + 0.2); // fade in
      mainGain.gain.exponentialRampToValueAtTime(0.001, now + duration); // fade out

      // Dynamic Bandpass filter to soften insect hum
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(4500, now);
      filter.Q.setValueAtTime(8, now);

      osc.connect(filter);
      filter.connect(mainGain);
      
      // Hook up AM modulation
      modulator.connect(modGain);
      modGain.connect(mainGain.gain);

      mainGain.connect(ctx.destination);

      osc.start(now);
      modulator.start(now);
      osc.stop(now + duration);
      modulator.stop(now + duration);
    };

    // Pulse loops
    const loop = () => {
      playCicadaPulse();
      const nextDelay = 3000 + Math.random() * 2500;
      this.ambientNodes.cricketsTimer = setTimeout(loop, nextDelay);
    };
    this.ambientNodes.cricketsTimer = setTimeout(loop, 1000);
  }

  // AUTUMN: Synthesize crickets chirping at night ("cheep-cheep-cheep")
  private startAutumnCrickets() {
    const ctx = this.ctx;
    if (!ctx) return;

    const playCricketSong = () => {
      if (this.isMuted || this.currentSeason !== 'autumn') return;
      const now = ctx.currentTime;
      
      const chirpLength = 0.04;
      const gap = 0.03;
      const chirpsCount = 4 + Math.floor(Math.random() * 3); // 4 to 6 sweet minor chirps in sequence
      
      for (let i = 0; i < chirpsCount; i++) {
        const delay = i * (chirpLength + gap);
        const osc = ctx.createOscillator();
        const subOsc = ctx.createOscillator();
        const mainGain = ctx.createGain();
        const subGain = ctx.createGain();
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(4800, now + delay);
        
        // Tremolo wing shake amplitude modulation at 45Hz
        subOsc.frequency.setValueAtTime(45, now + delay);
        subGain.gain.setValueAtTime(0.35, now + delay);
        
        mainGain.gain.setValueAtTime(0, now + delay);
        mainGain.gain.linearRampToValueAtTime(0.02, now + delay + 0.015);
        mainGain.gain.exponentialRampToValueAtTime(0.001, now + delay + chirpLength);

        osc.connect(mainGain);
        subOsc.connect(subGain);
        subGain.connect(mainGain.gain);
        
        mainGain.connect(ctx.destination);
        
        osc.start(now + delay);
        subOsc.start(now + delay);
        osc.stop(now + delay + chirpLength);
        subOsc.stop(now + delay + chirpLength);
      }
    };

    const loop = () => {
      playCricketSong();
      const nextDelay = 2500 + Math.random() * 2000;
      this.ambientNodes.cricketsTimer = setTimeout(loop, nextDelay);
    };
    this.ambientNodes.cricketsTimer = setTimeout(loop, 1500);
  }

  // WINTER: Synthesize slow cozy burning fireplace crackles and pops
  private startWinterCozyCrackles() {
    const ctx = this.ctx;
    if (!ctx) return;

    // Cozy fireplace wood-burning mini pops
    const triggerPop = () => {
      if (this.isMuted || this.currentSeason !== 'winter') return;
      const now = ctx.currentTime;
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      // Quick snap frequency drop
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(150 + Math.random() * 100, now);
      osc.frequency.exponentialRampToValueAtTime(15 + Math.random() * 5, now + 0.02);

      gain.gain.setValueAtTime(0, now);
      gain.gain.linearRampToValueAtTime(0.035, now + 0.001); // ultra-fast attack
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.02); // rapid decay

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.03);
    };

    const loop = () => {
      triggerPop();
      const nextDelay = 300 + Math.random() * 1400; // random crackling timing
      this.ambientNodes.cracklesTimer = setTimeout(loop, nextDelay);
    };
    this.ambientNodes.cracklesTimer = setTimeout(loop, 400);
  }
}

// Export singleton instance so all components share the same audio pipeline
export const gardenAudio = new GardenAudioSynth();
