/**
 * Offline Garden Event Reporter Generator
 * Programmatically generates realistic, customized timeline reports of what characters and environments
 * did in the garden while the user was away. Fits perfectly with the character personas.
 */

interface OfflineEvent {
  timeStr: string;
  type: 'weather' | 'companion' | 'flower' | 'general';
  desc: string;
  icon: string;
}

export function generateOfflineEvents(
  diffMs: number,
  characterId: string,
  flowerType: string
): OfflineEvent[] {
  const events: OfflineEvent[] = [];
  const now = Date.now();

  // Scale timeline depending on how long they were away
  const minutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(diffMs / (3600 * 1000));
  const days = Math.floor(diffMs / (24 * 3600 * 1000));

  if (characterId === 'naruto') {
    if (days >= 1) {
      events.push({
        timeStr: '第 1 天',
        type: 'weather',
        desc: '天空中突然下了一阵大雨。鸣人兴奋得连雨伞都没撑，大喊着“大自然的水遁真是厉害”在草地上狂奔。',
        icon: '🌧️',
      });
      events.push({
        timeStr: '第 2 天',
        type: 'companion',
        desc: `发现害虫靠近过 ${flowerType} 的幼苗，鸣人大喊着“看我的多重影分身之术！”放出分身把小虫们清理得一干二净。`,
        icon: '🥷',
      });
      events.push({
        timeStr: `${days} 天前`,
        type: 'flower',
        desc: `由于天气干燥，土壤有些变硬。鸣人有点不服输地大嚷着“这也是给我的修行！”，挥舞着铲子把大土块翻得蓬松又匀称。`,
        icon: '🪵',
      });
      events.push({
        timeStr: '刚刚',
        type: 'general',
        desc: '鸣人坐在地上肚子咕咕直叫，有些失望地嘟囔：“唉，说好今天一起吃一乐拉面的……不过花盆我已经用衣服擦得干干净净啦，等你来！”',
        icon: '🍜',
      });
    } else if (hours >= 1) {
      events.push({
        timeStr: `${Math.floor(hours * 0.7)} 小时前`,
        type: 'weather',
        icon: '🌤️',
        desc: '晴天的高温晒得土壤表面有些发白，鸣人用杯子颤颤巍巍地接了一点井水，小心翼翼地喂给花盆边缘。',
      });
      events.push({
        timeStr: '20 分钟前',
        type: 'companion',
        icon: '🐛',
        desc: '翻土的时候，鸣人发现一只伪装成枯叶的毛毛虫，本想用忍术轰飞，结果想起你的叮嘱，改用树枝极其轻柔地挑走了它。',
      });
      events.push({
        timeStr: '刚才',
        type: 'general',
        icon: '✨',
        desc: `鸣人一边在额角抹着汗，一边自豪地看着 ${flowerType}，两眼放光，“噢！看着它长这么大，修行真是没有白费的说！”`,
      });
    } else {
      // Shorter away time (minutes)
      events.push({
        timeStr: `${Math.floor(minutes / 2) || 2} 分钟前`,
        type: 'companion',
        icon: '🤸',
        desc: '鸣人在花盆周围做着单手倒立的俯卧撑特训，还大声对萌芽说：“好花儿！我们要一起变成火影，成为全村人的骄傲！”',
      });
      events.push({
        timeStr: '1 分钟前',
        type: 'flower',
        icon: '🫧',
        desc: '一片温暖的金色阳光悄然洒在花瓣上。鸣人屏住呼吸不敢打扰，只是默默坐在旁边傻笑。',
      });
    }
  } else if (characterId === 'ran') {
    if (days >= 1) {
      events.push({
        timeStr: '第 1 天',
        type: 'weather',
        desc: '天空下起了淅淅沥沥的碎雨。小兰温柔地撑开了一把淡粉色的雨伞，帮花盆一并遮风挡雨。',
        icon: '☔',
      });
      events.push({
        timeStr: '第 2 天',
        type: 'companion',
        desc: `小兰在草坪上仔细搜寻，把几颗细小的杂草连根拔起。她看着 ${flowerType} 的侧影，眼神有些忧伤，仿佛在想念某个总是缺席的新一。`,
        icon: '🎀',
      });
      events.push({
        timeStr: `${days} 天前`,
        type: 'flower',
        desc: '连日的无风让叶片有些落灰，小兰精心用温水和极软的棉布，一片片把叶片擦拭得宛如翡翠般光亮。',
        icon: '🍃',
      });
      events.push({
        timeStr: '刚刚',
        type: 'general',
        desc: '小兰泡好了一壶红茶，在桌前默默写信。偶尔转头看看花，幽幽叹了一口气：“如果那个人也像花一样，只要精心守候就能有回报就好了呢。”',
        icon: '☕',
      });
    } else if (hours >= 1) {
      events.push({
        timeStr: `${Math.floor(hours * 0.8)} 小时前`,
        type: 'weather',
        icon: '☀️',
        desc: '午后阳光炽热，小兰提前给阳台拉上了白纱帘，避免娇嫩的叶片被晒伤，还温柔地给周围空气喷了些水雾。',
      });
      events.push({
        timeStr: '15 分钟前',
        type: 'companion',
        icon: '✂️',
        desc: '小兰静静地在一旁练习着空手道出拳，风声呼呼作响，但只要每次落在花盆旁时，她都会瞬间收力，笑得无比甜美。',
      });
      events.push({
        timeStr: '刚才',
        type: 'flower',
        icon: '💖',
        desc: `小兰轻轻整理了花盆上的丝带扣，对 ${flowerType} 温柔呢喃：“他应该在忙着拯救世界或者破什么大案吧……所以，我就先替他把你照顾得好好的。”`,
      });
    } else {
      events.push({
        timeStr: `${Math.floor(minutes / 2) || 2} 分钟前`,
        type: 'companion',
        icon: '🧴',
        desc: '小兰捧着小喷壶均匀地往空气中洒一些温润的水雾，让花房充满令人安心的青草芬芳。',
      });
      events.push({
        timeStr: '1 分钟前',
        type: 'general',
        icon: '💭',
        desc: '小兰默默端详着花骨朵，拿手指轻轻贴了贴花瓣，眼中满含欣喜，“它刚才好像稍微舒展了一下，你如果现在在身边看到的话，也一定会很高兴吧。”',
      });
    }
  } else {
    // Kurapika or generic fallback
    if (days >= 1) {
      events.push({
        timeStr: '第 1 天',
        type: 'companion',
        desc: '酷拉皮卡戴起了白手套，用极度严苛的植物学比例配制了营养物质，并精准测定了土壤的酸碱度是否适合。',
        icon: '🧪',
      });
      events.push({
        timeStr: '第 2 天',
        type: 'weather',
        desc: '暴雨夜风很大，酷拉皮卡用两层防风原木板把花盆和土壤牢牢扣住，神色冷峻执着，发誓不会让它受到半分伤害。',
        icon: '🌬️',
      });
      events.push({
        timeStr: `${days} 天前`,
        type: 'flower',
        desc: `酷拉皮卡用绝念锁链把在花叶背面滋生的细微害虫尽数拂去，眼眸在那一瞬间闪过了红霞，又迅速归于绝对的平静。`,
        icon: '⛓️',
      });
      events.push({
        timeStr: '刚刚',
        type: 'general',
        desc: `酷拉皮卡默默靠在窗台，合上了厚厚的手稿，眉头微微锁起：“契约和诺言是高尚的象征。你若归来， ${flowerType} 刚才被我调理的黄金含水量，大约能继续坚挺 12 个小时。”`,
        icon: '⏳',
      });
    } else if (hours >= 1) {
      events.push({
        timeStr: `${Math.floor(hours * 0.8)} 小时前`,
        type: 'companion',
        icon: '🔍',
        desc: '酷拉皮卡用放大镜在叶片的每个脉络上逐一勘察。对一些细碎的落叶进行了无害的环保收集。',
      });
      events.push({
        timeStr: '25 分钟前',
        type: 'weather',
        icon: '🌦️',
        desc: '小雨初歇，微湿的空气是绝佳的吐纳环境，酷拉皮卡静静盘坐一旁，双手自然垂立，借此微润之气修炼锁链的稳定性。',
      });
      events.push({
        timeStr: '刚才',
        type: 'general',
        icon: '📖',
        desc: `他写下了三页密密麻麻的《养殖日记与温控系数》，字迹凌厉而隽秀。他在等待着再次向你展示他的绝对理性成果。`,
      });
    } else {
      events.push({
        timeStr: `${Math.floor(minutes / 2) || 2} 分钟前`,
        type: 'companion',
        icon: '👓',
        desc: '酷拉皮卡极其克制地用镊子挑去了一粒微尘，调整了花盆受光的角度至精确的 35 度极佳方位。',
      });
      events.push({
        timeStr: '1 分钟前',
        type: 'flower',
        icon: '🕯️',
        desc: '一小片花影投射在酷拉皮卡的衣角上。他就这样如雕塑般长久伫立着，像是在守护古老而珍贵的圣物。',
      });
    }
  }

  return events;
}
