/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CharacterData, FlowerData, GameState } from "../types";

export async function getAIDialogue(
  character: CharacterData,
  flower: FlowerData,
  state: GameState,
  action?: string
) {
  try {
    const response = await fetch("/api/dialogue", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ character, flower, state, action }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.text || "……（默默地看着花）";
  } catch (error) {
    console.error("Client getAIDialogue error calling server API:", error);
    return "（似乎在思考什么，没有说话）";
  }
}

export async function getAICharacterLetter(
  writerCharacter: CharacterData,
  flowerNames: string,
  isJealous: boolean,
  targetName: string,
  userCardMessage?: string
) {
  try {
    const response = await fetch("/api/letter", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        writerCharacter,
        flowerNames,
        isJealous,
        targetName,
        userCardMessage,
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return data.text || "谢谢你的花。";
  } catch (error) {
    console.error("Client getAICharacterLetter error calling server API:", error);
    return "由于信号不好，信件未能送达...";
  }
}
