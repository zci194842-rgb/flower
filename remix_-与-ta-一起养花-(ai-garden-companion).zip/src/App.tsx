/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Droplets, 
  Sprout, 
  Bug, 
  Trash2, 
  FlaskConical, 
  Calendar, 
  Clock, 
  Sun, 
  CloudRain, 
  Wind,
  Pickaxe as Shovel,
  ArrowRight,
  RefreshCw,
  Heart,
  Flower,
  Flower2,
  Gift,
  Mail,
  ShoppingBasket as Basket,
  X,
  Lock,
  Volume2,
  VolumeX,
  BookOpen,
  Sparkles,
  Award
} from 'lucide-react';
import { FlowerType, FlowerData, CharacterData, GameState, FLOWERS, CHARACTERS, POTS, Letter, PREMIUM_BOUQUETS, GameEvent } from './types.ts';
import { getAIDialogue, getAICharacterLetter } from './services/geminiService.ts';
import { gardenAudio } from './utils/audioSynth.ts';
import { generateOfflineEvents } from './utils/offlineReporter.ts';

const INITIAL_STATE: GameState = {
  flowerType: null,
  characterId: null,
  potStyle: null,
  startTime: Date.now(),
  lastActiveTime: Date.now(),
  flowerHealth: 80,
  flowerStage: 'seed',
  hatredPoints: 0,
  waterLevel: 50,
  soilQuality: 50,
  pestLevel: 0,
  weedsLevel: 0,
  history: [],
  bouquets: [],
  letters: [],
  unlockedFlowers: [],
  completedPremiumBouquets: [],
  claimedBookReward: false,
  walletStone: 0,
  unlockedFrames: [],
};

const ABSENCE_LIMIT_DAYS = 10;
const MS_PER_DAY = 24 * 60 * 60 * 1000;

const isImageAvatar = (avatar: string) => avatar.startsWith('http') || avatar.startsWith('/');

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => {
    const saved = localStorage.getItem('flower_game_state');
    if (!saved) return INITIAL_STATE;
    try {
      const parsed = JSON.parse(saved);
      const bouquetsList = parsed.bouquets || [];
      const unlockedList = parsed.unlockedFlowers || [];
      return {
        ...INITIAL_STATE,
        ...parsed,
        bouquets: bouquetsList,
        letters: parsed.letters || [],
        history: parsed.history || [],
        unlockedFlowers: Array.from(new Set([...unlockedList, ...bouquetsList]))
      };
    } catch (e) {
      return INITIAL_STATE;
    }
  });
  
  const [aiMessage, setAiMessage] = useState<string>('');
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [weather, setWeather] = useState<'sunny' | 'rainy'>('sunny');
  const [season, setSeason] = useState<'spring' | 'summer' | 'autumn' | 'winter'>(() => {
    const month = new Date().getMonth(); // 0-11
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    if (month >= 8 && month <= 10) return 'autumn';
    return 'winter';
  });
  const [isUserActive, setIsUserActive] = useState(false);

  // Ambient Sound Feature
  const [ambientMuted, setAmbientMuted] = useState<boolean>(true);
  const birdsAudioRef = useRef<HTMLAudioElement | null>(null);
  const rainAudioRef = useRef<HTMLAudioElement | null>(null);

  // Initialize volume to 0 to prevent harsh starts
  useEffect(() => {
    if (birdsAudioRef.current) birdsAudioRef.current.volume = 0;
    if (rainAudioRef.current) rainAudioRef.current.volume = 0;
  }, []);

  // Synchronize audio playback based on weather and mute state with beautiful fading transitions
  useEffect(() => {
    // Sync the programmatically synthesized background soundscapes (spring birds, summer cicadas, autumn crickets, winter cozy fire)
    gardenAudio.updateAmbient(season, weather, ambientMuted);

    const birds = birdsAudioRef.current;
    const rain = rainAudioRef.current;
    if (!birds || !rain) return;

    let intervalId: NodeJS.Timeout;

    if (ambientMuted) {
      // Fade out both smoothly
      intervalId = setInterval(() => {
        let isDone = true;
        if (birds.volume > 0) {
          birds.volume = Math.max(0, birds.volume - 0.05);
          isDone = false;
        }
        if (rain.volume > 0) {
          rain.volume = Math.max(0, rain.volume - 0.05);
          isDone = false;
        }
        if (isDone) {
          birds.pause();
          rain.pause();
          clearInterval(intervalId);
        }
      }, 50);
    } else {
      // Play both so they can loop and blend perfectly
      birds.play().catch(err => console.log("Audio autoplay restricted:", err));
      rain.play().catch(err => console.log("Audio autoplay restricted:", err));

      const targetBirdsVol = weather === 'sunny' ? 0.6 : 0.05; // soft chirping background in rainy mood
      const targetRainVol = weather === 'rainy' ? 0.7 : 0.0; // absolute silence for rain in sunny mood

      intervalId = setInterval(() => {
        let isDone = true;
        
        // Fade birds to target
        if (Math.abs(birds.volume - targetBirdsVol) > 0.05) {
          birds.volume = birds.volume < targetBirdsVol 
            ? Math.min(targetBirdsVol, birds.volume + 0.05)
            : Math.max(targetBirdsVol, birds.volume - 0.05);
          isDone = false;
        }
        
        // Fade rain to target
        if (Math.abs(rain.volume - targetRainVol) > 0.05) {
          rain.volume = rain.volume < targetRainVol 
            ? Math.min(targetRainVol, rain.volume + 0.05)
            : Math.max(targetRainVol, rain.volume - 0.05);
          isDone = false;
        }
        
        if (isDone) {
          clearInterval(intervalId);
        }
      }, 50);
    }

    return () => {
      clearInterval(intervalId);
    };
  }, [ambientMuted, weather, season]);
  const [activeTab, setActiveTab] = useState<'garden' | 'collection' | 'inbox'>('garden');
  const [selectedLetter, setSelectedLetter] = useState<Letter | null>(null);
  const [showGiftModal, setShowGiftModal] = useState<{flowerIndex: number} | null>(null);
  const [selectedBouquetIndices, setSelectedBouquetIndices] = useState<number[]>([]);
  const [showBundleModal, setShowBundleModal] = useState<boolean>(false);
  const [showHandbook, setShowHandbook] = useState<boolean>(false);
  const [showWitheringNotice, setShowWitheringNotice] = useState<boolean>(false);
  const [dontShowAgainChecked, setDontShowAgainChecked] = useState<boolean>(false);
  const [offlineLog, setOfflineLog] = useState<{
    timeAwayStr: string;
    events: { timeStr: string; type: 'weather' | 'companion' | 'flower' | 'general'; desc: string; icon: string }[];
  } | null>(null);
  const [nudgeMessage, setNudgeMessage] = useState<string>('');
  const [hasInteracted, setHasInteracted] = useState(false);
  const userActiveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Weather Cycle (Toggle every 2 mins)
  useEffect(() => {
    const timer = setInterval(() => {
      setWeather(prev => prev === 'sunny' ? 'rainy' : 'sunny');
    }, 120000);
    return () => clearInterval(timer);
  }, []);

  // Season Cycle (Cycle seasons every 3 mins smoothly)
  useEffect(() => {
    const timer = setInterval(() => {
      setSeason(prev => {
        const order: ('spring' | 'summer' | 'autumn' | 'winter')[] = [
          'spring',
          'summer',
          'autumn',
          'winter'
        ];
        const nextIdx = (order.indexOf(prev) + 1) % order.length;
        return order[nextIdx];
      });
    }, 180000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!isUserActive && !hasInteracted && gameState.flowerType && gameState.characterId) {
      const messages = [
        "爱人如养花，你对我真差...",
        "花都快干了，你在哪里呀？",
        "就算再忙也要记得喝水，给花也浇一点嘛。",
        "我是不是被你遗忘了呢？",
        "好期待你下一次出现呀...",
        "养花也是需要耐心的，别丢下我一个人呀。",
        "花朵正在悄悄生长，你快来看看呀。"
      ];
      setNudgeMessage(messages[Math.floor(Math.random() * messages.length)]);
    } else {
      setNudgeMessage('');
    }
  }, [isUserActive, hasInteracted, gameState.flowerType, gameState.characterId]);

  // Reset interaction state on new planting
  useEffect(() => {
    if (gameState.flowerType && gameState.flowerStage === 'seed') {
      setHasInteracted(false);
    }
  }, [gameState.flowerType, gameState.flowerStage]);

  // Save state on change
  useEffect(() => {
    localStorage.setItem('flower_game_state', JSON.stringify(gameState));
  }, [gameState]);

  // Clock
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Withering Notification Daily Rule Checker for Care Screen ("养花小卫士")
  useEffect(() => {
    if (gameState.flowerType && gameState.characterId && activeTab === 'garden') {
      const dontShow = localStorage.getItem('dontShowWitheringNotice') === 'true';
      if (!dontShow) {
        const todayStr = new Date().toDateString();
        const lastShown = localStorage.getItem('lastWitheringNoticeShownDate');
        if (lastShown !== todayStr) {
          setShowWitheringNotice(true);
          localStorage.setItem('lastWitheringNoticeShownDate', todayStr);
        }
      }
    }
  }, [activeTab, gameState.flowerType, gameState.characterId]);

  // Check absence and wither logic
  useEffect(() => {
    if (gameState.flowerType && gameState.characterId) {
      const now = Date.now();
      const diffMs = now - gameState.lastActiveTime;

      // Offline report if away for >= 60 seconds (1 minute for simple testing)
      const OFFLINE_THRESHOLD_MS = 60 * 1000;
      if (diffMs >= OFFLINE_THRESHOLD_MS) {
        const events = generateOfflineEvents(diffMs, gameState.characterId, gameState.flowerType);
        const daysAway = Math.floor(diffMs / (24 * 3600 * 1000));
        const hoursAway = Math.floor((diffMs % (24 * 3600 * 1000)) / (3600 * 1000));
        const minsAway = Math.floor((diffMs % (3600 * 1000)) / 60000) || 1;
        let timeAwayStr = '';
        if (daysAway > 0) {
          timeAwayStr = `${daysAway}天${hoursAway}小时`;
        } else if (hoursAway > 0) {
          timeAwayStr = `${hoursAway}小时${minsAway}分钟`;
        } else {
          timeAwayStr = `${minsAway}分钟`;
        }
        setOfflineLog({
          timeAwayStr,
          events
        });
      }

      const diffDays = Math.floor(diffMs / MS_PER_DAY);

      if (diffDays >= ABSENCE_LIMIT_DAYS && gameState.flowerStage !== 'withered') {
        const newHatred = gameState.hatredPoints + 1;
        setGameState(prev => ({
          ...prev,
          flowerStage: 'withered',
          flowerHealth: 0,
          hatredPoints: newHatred,
          lastActiveTime: now,
          history: [...prev.history, { 
            time: now, 
            type: 'wither', 
            description: `缺席${diffDays}天，花已枯萎，角色恨意+1` 
          }]
        }));
        setAiMessage('你终于出现了……但已经太晚了。看来这朵花并不值得你费心。');
      } else {
        // Just update last active time on load
        setGameState(prev => ({ ...prev, lastActiveTime: now }));
        if (!aiMessage && !isAiThinking) {
          triggerAiDialogue();
        }
      }
    }
  }, []);

  const triggerAiDialogue = async (action?: string) => {
    if (!gameState.characterId || !gameState.flowerType) return;
    
    setIsAiThinking(true);
    const char = CHARACTERS.find(c => c.id === gameState.characterId)!;
    const flower = FLOWERS.find(f => f.type === gameState.flowerType)!;
    
    const msg = await getAIDialogue(char, flower, gameState, action);
    setAiMessage(msg);
    setIsAiThinking(false);
  };

  const handleAction = (type: 'water' | 'soil' | 'pest' | 'weed' | 'nutrient') => {
    if (gameState.flowerStage === 'withered') return;

    // Trigger program sound synthesis for the active tool
    gardenAudio.playToolSound(type);

    // Trigger user active state for avatar brightness
    setIsUserActive(true);
    setHasInteracted(true);
    if (userActiveTimeoutRef.current) clearTimeout(userActiveTimeoutRef.current);
    userActiveTimeoutRef.current = setTimeout(() => setIsUserActive(false), 5000);

    let updates: Partial<GameState> = {};
    let desc = '';

    switch (type) {
      case 'water':
        updates = { waterLevel: Math.min(100, gameState.waterLevel + 20), flowerHealth: Math.min(100, gameState.flowerHealth + 5) };
        desc = '浇水';
        break;
      case 'soil':
        updates = { soilQuality: Math.min(100, gameState.soilQuality + 20) };
        desc = '翻土';
        break;
      case 'pest':
        updates = { pestLevel: Math.max(0, gameState.pestLevel - 30) };
        desc = '除虫';
        break;
      case 'weed':
        updates = { weedsLevel: Math.max(0, gameState.weedsLevel - 30) };
        desc = '除草';
        break;
      case 'nutrient':
        updates = { flowerHealth: Math.min(100, gameState.flowerHealth + 15), waterLevel: Math.max(0, gameState.waterLevel - 5) };
        desc = '施肥';
        break;
    }

    // Progression Logic
    let nextStage = gameState.flowerStage;
    const h = (updates.flowerHealth ?? gameState.flowerHealth);
    const w = (updates.waterLevel ?? gameState.waterLevel);
    const s = (updates.soilQuality ?? gameState.soilQuality);
    const p = (updates.pestLevel ?? gameState.pestLevel);

    if (gameState.flowerStage === 'seed' && h > 60) {
      nextStage = 'sprout';
    } else if (gameState.flowerStage === 'sprout' && h > 80 && w > 60 && s > 60) {
      nextStage = 'growing';
    } else if (gameState.flowerStage === 'growing' && h > 95 && w > 70 && s > 70 && p < 10) {
      nextStage = 'blooming';
    }

    if (nextStage !== gameState.flowerStage) {
      updates.flowerStage = nextStage;
      desc += ` (进化为 ${nextStage}!)`;
      // Play celebratory sound if it just bloomed!
      if (nextStage === 'blooming') {
        setTimeout(() => {
          gardenAudio.playBloomFanfare();
        }, 300);
      }
    }

    const newState = {
      ...gameState,
      ...updates,
      history: [...gameState.history, { time: Date.now(), type, description: desc }]
    };
    
    setGameState(newState);
    triggerAiDialogue(desc);
  };

  const handleHarvest = () => {
    if (gameState.flowerStage !== 'blooming') return;
    setHasInteracted(true);
    
    const flowerType = gameState.flowerType!;
    setGameState(prev => {
      const currentUnlocked = prev.unlockedFlowers || [];
      return {
        ...prev,
        flowerHealth: 50,
        waterLevel: 50,
        soilQuality: 50,
        pestLevel: 0,
        weedsLevel: 0,
        flowerStage: 'harvested', 
        bouquets: [...prev.bouquets, flowerType],
        unlockedFlowers: Array.from(new Set([...currentUnlocked, flowerType])),
        history: [...prev.history, { 
          time: Date.now(), 
          type: 'harvest', 
          description: `采摘了一束 ${flowerType}` 
        }]
      };
    });
    setAiMessage(`这束${flowerType}开得真美，你要把它送给谁呢？`);
  };

  const handleToggleSelectBouquet = (index: number) => {
    setSelectedBouquetIndices(prev => 
      prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]
    );
  };

  const handleBundleGift = async (targetIds: string[], cardMessage: string) => {
    if (selectedBouquetIndices.length < 3) return;
    
    const selectedFlowers = selectedBouquetIndices.map(i => gameState.bouquets[i]);
    const flowerNames = selectedFlowers.join('、');
    const currentCompanion = CHARACTERS.find(c => c.id === gameState.characterId)!;
    
    // Jealousy: if multiple recipients OR any recipient is NOT the companion
    const isGiftingToOthers = targetIds.some(id => id !== gameState.characterId);
    const isMultiGift = targetIds.length > 1;
    const isJealous = isGiftingToOthers || isMultiGift;

    setIsAiThinking(true);
    
    // Generate letter from partner (Jealousy source)
    const targetNames = targetIds.map(id => CHARACTERS.find(c => c.id === id)?.name).join('、');
    
    const companionPromise = getAICharacterLetter(
      currentCompanion, 
      flowerNames, 
      isJealous, 
      targetNames, 
      cardMessage
    );

    // Concurrently fetch appreciation letters from other recipients if gifted to them
    const otherRecipients = targetIds.filter(id => id !== gameState.characterId);
    const otherPromises = otherRecipients.map(async (otherId, index) => {
      const recipientChar = CHARACTERS.find(c => c.id === otherId);
      if (recipientChar) {
        const letterText = await getAICharacterLetter(
          recipientChar,
          flowerNames,
          false,
          recipientChar.name,
          cardMessage
        );
        return {
          id: Math.random().toString(36).substr(2, 9),
          fromId: recipientChar.id,
          fromName: recipientChar.name,
          content: letterText,
          time: Date.now() + 50 + index, // slightly offset time to show order nicely
          isJealous: false
        };
      }
      return null;
    });

    const [companionLetterContent, ...otherLetters] = await Promise.all([
      companionPromise,
      ...otherPromises
    ]);

    const generatedLetters: Letter[] = [
      {
        id: Math.random().toString(36).substr(2, 9),
        fromId: currentCompanion.id,
        fromName: currentCompanion.name,
        content: companionLetterContent,
        time: Date.now(),
        isJealous
      }
    ];

    otherLetters.forEach(l => {
      if (l) generatedLetters.push(l);
    });

    // Update state: remove used flowers, add letters
    setGameState(prev => {
      let newHatred = prev.hatredPoints;
      if (isJealous) {
        newHatred = Math.min(100, newHatred + 10); // Bundling for others is worse
      } else {
        newHatred = Math.max(0, newHatred - 25); // High reward for bundling for companion
      }

      const updatedState = {
        ...prev,
        bouquets: prev.bouquets.filter((_, i) => !selectedBouquetIndices.includes(i)),
        letters: [...generatedLetters, ...prev.letters],
        hatredPoints: newHatred,
        history: [
          ...prev.history,
          {
            time: Date.now(),
            type: 'gift' as const,
            description: `将 ${flowerNames} 包成花束送给了 ${targetNames}`
          }
        ]
      };

      localStorage.setItem('flower_game_state', JSON.stringify(updatedState));
      return updatedState;
    });

    setIsAiThinking(false);
    setSelectedBouquetIndices([]);
    setShowBundleModal(false);
    
    if (isJealous && targetIds.includes(gameState.characterId)) {
      setAiMessage(`同时送出花束！${currentCompanion.name}心里酸溜溜的，醋意大发；而接收者非常感谢你。快去收件箱看信件。`);
    } else {
      setAiMessage(`礼轻情意重，${targetNames}一定会感受到你的心意的。快去收件箱查看信件。`);
    }
    
    setActiveTab('inbox');
  };

  const handleGift = async (targetCharacterId: string, flowerIndex: number) => {
    const flowerType = gameState.bouquets[flowerIndex];
    if (!flowerType) return;

    const targetChar = CHARACTERS.find(c => c.id === targetCharacterId)!;
    const currentCompanion = CHARACTERS.find(c => c.id === gameState.characterId)!;
    const isJealous = targetCharacterId !== gameState.characterId;

    setIsAiThinking(true);

    const companionPromise = getAICharacterLetter(
      currentCompanion,
      flowerType,
      isJealous,
      targetChar.name,
      ''
    );

    let recipientPromise: Promise<string | null> = Promise.resolve(null);
    if (isJealous) {
      recipientPromise = getAICharacterLetter(
        targetChar,
        flowerType,
        false,
        targetChar.name,
        ''
      );
    }

    const [companionLetterContent, recipientLetterContent] = await Promise.all([
      companionPromise,
      recipientPromise
    ]);

    const generatedLetters: Letter[] = [
      {
        id: Math.random().toString(36).substr(2, 9),
        fromId: currentCompanion.id,
        fromName: currentCompanion.name,
        content: companionLetterContent,
        time: Date.now(),
        isJealous
      }
    ];

    if (recipientLetterContent) {
      generatedLetters.push({
        id: Math.random().toString(36).substr(2, 9),
        fromId: targetChar.id,
        fromName: targetChar.name,
        content: recipientLetterContent,
        time: Date.now() + 50,
        isJealous: false
      });
    }

    setGameState(prev => {
      const newBouquets = [...prev.bouquets];
      newBouquets.splice(flowerIndex, 1);
      
      let newHatred = prev.hatredPoints;
      if (isJealous) {
        newHatred = Math.min(100, newHatred + 5); 
      } else {
        newHatred = Math.max(0, newHatred - 10); // Reward for gifting to him/her
      }

      const updatedState = {
        ...prev,
        bouquets: newBouquets,
        letters: [...generatedLetters, ...prev.letters],
        hatredPoints: newHatred,
        history: [...prev.history, { 
          time: Date.now(), 
          type: 'gift' as const, 
          description: `直接送给 ${targetChar.name} 一束 ${flowerType}` 
        }]
      };

      localStorage.setItem('flower_game_state', JSON.stringify(updatedState));
      return updatedState;
    });

    setIsAiThinking(false);

    if (isJealous) {
      setAiMessage(`${currentCompanion.name}: “你居然把花送给 ${targetChar.name} 了？那个花分明也有我的一份修行在里面吧... 快去收件箱看信件。”`);
    } else {
      setAiMessage(`${currentCompanion.name}: “给我的吗？嘿嘿，谢谢你！我会好好珍惜这朵花的！可以去收件箱查看信件。”`);
    }

    setShowGiftModal(null);
    setActiveTab('inbox');
  };

  const handleReset = () => {
    localStorage.removeItem('flower_game_state');
    setGameState(INITIAL_STATE);
  };

  // UI Component
  return (
    <div className="app-container">
      {/* HTML5 Audio Elements for Ambient Sounds */}
      <audio ref={birdsAudioRef} loop preload="auto" id="audio-birds" muted={false}>
        <source src="https://raw.githubusercontent.com/Anand-Chowdhary/relax/master/public/audio/birds.mp3" type="audio/mpeg" />
        <source src="https://upload.wikimedia.org/wikipedia/commons/a/a2/Turdus_merula_-_Common_Blackbird_-_bird_song_in_garden_setting.ogg" type="audio/ogg" />
      </audio>
      <audio ref={rainAudioRef} loop preload="auto" id="audio-rain" muted={false}>
        <source src="https://raw.githubusercontent.com/Anand-Chowdhary/relax/master/public/audio/rain.mp3" type="audio/mpeg" />
        <source src="https://upload.wikimedia.org/wikipedia/commons/e/e0/Rain_falling_on_the_roof_of_a_plastic_greenhouse.ogg" type="audio/ogg" />
      </audio>

      {/* Global Grainy Overlay */}
      <div className="absolute inset-0 pointer-events-none z-[100] opacity-[0.03] mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')]" />
      
      {/* Container Internal Logic */}
      <AnimatePresence mode="wait">
        {!gameState.flowerType || !gameState.characterId || !gameState.potStyle ? (
          <SelectionView gameState={gameState} setGameState={setGameState} />
        ) : (
          <GameView 
            gameState={gameState} 
            handleAction={handleAction} 
            handleReset={handleReset}
            currentTime={currentTime}
            aiMessage={aiMessage}
            isAiThinking={isAiThinking}
            weather={weather}
            setWeather={setWeather}
            isUserActive={isUserActive}
            handleHarvest={handleHarvest}
            setGameState={setGameState}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            bouquetsCount={gameState.bouquets.length}
            lettersCount={gameState.letters.length}
            nudgeMessage={nudgeMessage}
            ambientMuted={ambientMuted}
            setAmbientMuted={setAmbientMuted}
            season={season}
            setSeason={setSeason}
            onOpenHandbook={() => setShowHandbook(true)}
          />
        )}
      </AnimatePresence>

      <AnimatePresence>
        {activeTab === 'collection' && (
          <BasketView 
            bouquets={gameState.bouquets} 
            selectedIndices={selectedBouquetIndices}
            onToggleSelect={handleToggleSelectBouquet}
            onClose={() => { setActiveTab('garden'); setSelectedBouquetIndices([]); }} 
            onGift={(index) => setShowGiftModal({ flowerIndex: index })}
            onOpenBundle={() => setShowBundleModal(true)}
            unlockedFlowers={gameState.unlockedFlowers || []}
            onOpenHandbook={() => setShowHandbook(true)}
          />
        )}
        {activeTab === 'inbox' && (
          <InboxView 
            letters={gameState.letters} 
            onClose={() => setActiveTab('garden')} 
            onSelectLetter={setSelectedLetter}
            selectedLetter={selectedLetter}
          />
        )}
        {showGiftModal && (
          <GiftModal 
            flowerType={gameState.bouquets[showGiftModal.flowerIndex]}
            onClose={() => setShowGiftModal(null)}
            onGift={(charId) => handleGift(charId, showGiftModal.flowerIndex)}
          />
        )}
        {showBundleModal && (
          <BundleBouquetModal 
            selectedFlowers={selectedBouquetIndices.map(i => gameState.bouquets[i])}
            onClose={() => setShowBundleModal(false)}
            onGift={handleBundleGift}
          />
        )}
        {showHandbook && (
          <HandbookModal 
            gameState={gameState}
            setGameState={setGameState}
            onClose={() => setShowHandbook(false)}
          />
        )}
        {showWitheringNotice && (
          <WitheringNoticeModal 
            dontShowAgainChecked={dontShowAgainChecked}
            setDontShowAgainChecked={setDontShowAgainChecked}
            onClose={() => {
              if (dontShowAgainChecked) {
                localStorage.setItem('dontShowWitheringNotice', 'true');
              }
              gardenAudio.playClickSound();
              setShowWitheringNotice(false);
            }}
          />
        )}
        {offlineLog && (
          <OfflineLogModal
            offlineLog={offlineLog}
            onClose={() => {
              gardenAudio.playClickSound();
              setOfflineLog(null);
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

const SelectionView = ({ gameState, setGameState }: { gameState: GameState, setGameState: React.Dispatch<React.SetStateAction<GameState>> }) => (
  <div className="h-full bg-garden-bg flex flex-col p-6 overflow-y-auto">
    <header className="mb-8 pt-4 text-center shrink-0">
      <h1 className="text-2xl font-serif font-bold mb-2">AI 养花伴侣</h1>
      <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Digital Zen Garden</p>
    </header>

    {!gameState.flowerType ? (
      <motion.div 
        key="flower-select"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="flex-1"
      >
        <h2 className="text-sm font-bold mb-4 text-center bg-black/5 py-1 rounded-full px-4 w-fit mx-auto">第一步：选择一粒种子</h2>
        <div className="grid grid-cols-2 gap-3 pb-8">
          {FLOWERS.map(f => (
            <button
              key={f.type}
              onClick={() => setGameState(prev => ({ ...prev, flowerType: f.type }))}
              className="p-4 bg-white rounded-2xl border-2 border-transparent hover:border-garden-ink transition-all text-left flex flex-col gap-1 group"
            >
              <span className="text-3xl group-hover:scale-110 transition-transform flex items-center justify-center h-10 w-10">
                {isImageAvatar(f.image) ? (
                  <img src={f.image} alt={f.name} className="w-full h-full object-contain" referrerPolicy="no-referrer" />
                ) : (
                  f.image
                )}
              </span>
              <span className="font-bold text-sm tracking-tight">{f.type}</span>
              <p className="text-[9px] text-gray-500 leading-tight line-clamp-2">{f.description}</p>
            </button>
          ))}
        </div>
      </motion.div>
    ) : !gameState.characterId ? (
      <motion.div 
        key="char-select"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="flex-1"
      >
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => setGameState(prev => ({ ...prev, flowerType: null }))} className="p-2 hover:bg-black/5 rounded-full transition-colors shrink-0">
            <RefreshCw size={14} />
          </button>
          <h2 className="text-sm font-bold bg-black/5 py-1 rounded-full px-4 flex-1 text-center">第二步：选择一位伙伴</h2>
        </div>
        <div className="flex flex-col gap-4 pb-8">
          {CHARACTERS.map(c => (
            <button
              key={c.id}
              onClick={() => setGameState(prev => ({ ...prev, characterId: c.id }))}
              className="p-5 bg-white rounded-3xl border-2 border-transparent hover:border-garden-ink transition-all flex flex-col gap-3 group"
            >
              <div className="flex items-center gap-4">
                <div className="bg-garden-bg w-14 h-14 flex items-center justify-center rounded-2xl group-hover:rotate-6 transition-transform shrink-0 overflow-hidden">
                  {isImageAvatar(c.avatar) ? (
                    <img src={c.avatar} alt={c.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <span className="text-4xl">{c.avatar}</span>
                  )}
                </div>
                <div className="text-left">
                  <span className="block font-bold text-base mb-0.5">{c.name}</span>
                  <p className="text-[10px] text-gray-500 leading-tight">{c.description}</p>
                </div>
              </div>
              <div className="w-full h-px bg-black/5" />
              <div className="text-[9px] font-mono uppercase tracking-widest text-garden-ink/40 text-left">
                {c.personality}
              </div>
            </button>
          ))}
        </div>
      </motion.div>
    ) : (
      <motion.div 
        key="pot-select"
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -20 }}
        className="flex-1"
      >
        <div className="flex items-center gap-3 mb-6">
          <button onClick={() => setGameState(prev => ({ ...prev, characterId: null }))} className="p-2 hover:bg-black/5 rounded-full transition-colors shrink-0">
            <RefreshCw size={14} />
          </button>
          <h2 className="text-sm font-bold bg-black/5 py-1 rounded-full px-4 flex-1 text-center">第三步：选择款式</h2>
        </div>
        <div className="grid grid-cols-1 gap-4 pb-8">
          {POTS.map(p => (
            <button
              key={p.id}
              onClick={() => setGameState(prev => ({ ...prev, potStyle: p.id }))}
              className="p-6 bg-white rounded-3xl border-2 border-transparent hover:border-garden-ink transition-all flex items-center gap-6 group"
            >
              <span className="text-5xl group-hover:scale-110 transition-transform">{p.image}</span>
              <div className="text-left">
                <span className="block font-bold text-lg">{p.name}</span>
                <div className="flex gap-2 mt-2">
                  <div className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.color }} />
                  <div className="w-4 h-4 rounded-full border border-black/10" style={{ backgroundColor: p.borderColor }} />
                </div>
              </div>
            </button>
          ))}
        </div>
      </motion.div>
    )}
  </div>
);

const GameView = ({ 
  gameState, handleAction, handleReset, currentTime, aiMessage, isAiThinking, 
  weather, setWeather, isUserActive, handleHarvest, setGameState, activeTab, setActiveTab,
  bouquetsCount, lettersCount, nudgeMessage, ambientMuted, setAmbientMuted,
  season, setSeason, onOpenHandbook
}: { 
  gameState: GameState, 
  handleAction: (t: any) => void, 
  handleReset: () => void,
  currentTime: Date,
  aiMessage: string,
  isAiThinking: boolean,
  weather: 'sunny' | 'rainy',
  setWeather: React.Dispatch<React.SetStateAction<'sunny' | 'rainy'>>,
  isUserActive: boolean,
  handleHarvest: () => void,
  setGameState: React.Dispatch<React.SetStateAction<GameState>>,
  activeTab: string,
  setActiveTab: (t: any) => void,
  bouquetsCount: number,
  lettersCount: number,
  nudgeMessage: string,
  ambientMuted: boolean,
  setAmbientMuted: (m: boolean) => void,
  season: 'spring' | 'summer' | 'autumn' | 'winter',
  setSeason: React.Dispatch<React.SetStateAction<'spring' | 'summer' | 'autumn' | 'winter'>>,
  onOpenHandbook: () => void
}) => {
  const currentFlower = FLOWERS.find(f => f.type === gameState.flowerType)!;
  const currentCharacter = CHARACTERS.find(c => c.id === gameState.characterId)!;
  const currentPot = POTS.find(p => p.id === gameState.potStyle) || POTS[0];

  const seasonBackgrounds = {
    spring: 'linear-gradient(-45deg, #fcedf2, #e8f5e9, #fff9c4, #e1f5fe, #fcedf2)',
    summer: 'linear-gradient(-45deg, #e0f2f1, #e8f5e9, #ffecb3, #b2dfdb, #e0f2f1)',
    autumn: 'linear-gradient(-45deg, #fff3e0, #ffe0b2, #ffebee, #ffe082, #fff3e0)',
    winter: 'linear-gradient(-45deg, #eceff1, #e1f5fe, #e0f7fa, #f5f5f5, #eceff1)'
  };

  return (
    <div className="relative h-full animated-bg overflow-hidden select-none transition-all duration-[2000ms]" style={{ 
      backgroundImage: gameState.flowerStage === 'withered'
        ? 'linear-gradient(-45deg, #eceff1, #cfd8dc, #b0bec5, #90a4ae)'
        : seasonBackgrounds[season]
    }}>
      {/* Weather Overlay for Darkening */}
      <motion.div 
        animate={{ backgroundColor: weather === 'rainy' ? 'rgba(0, 20, 40, 0.2)' : 'rgba(0, 0, 0, 0)' }}
        className="absolute inset-0 pointer-events-none z-[5] transition-colors duration-[3000ms]"
      />

      {/* Season Ambient Color Tint Overlay */}
      <div 
        className="absolute inset-0 pointer-events-none z-[6] transition-colors duration-[2500ms]" 
        style={{
          boxShadow: 'inset 0 0 120px rgba(0,0,0,0.03)',
          backgroundColor: season === 'spring' ? 'rgba(244, 143, 177, 0.04)'
            : season === 'summer' ? 'rgba(255, 235, 59, 0.03)'
            : season === 'autumn' ? 'rgba(230, 81, 0, 0.05)'
            : 'rgba(3, 169, 244, 0.04)'
        }}
      />

      {/* Nav Sidebar Buttons (Top Right) */}
      <div className="absolute top-8 right-4 flex flex-col gap-2 z-[60] pointer-events-auto">
        {/* Ambient Sound Controller */}
        <button 
          id="audio-ambient-toggle-btn"
          onClick={() => setAmbientMuted(!ambientMuted)}
          className={`glass-panel p-2 py-2 flex flex-col items-center justify-center relative group hover:bg-white/60 transition-all border-none ${
            !ambientMuted ? 'text-pink-600 bg-pink-50/70 border border-pink-100/50' : 'text-garden-ink/70'
          }`}
          title={ambientMuted ? "开启环境音效 (鸟鸣/细雨)" : "静音环境音效"}
        >
          {ambientMuted ? <VolumeX size={18} className="mb-0.5" /> : (
            <div className="relative mb-0.5">
              <Volume2 size={18} className="animate-pulse" />
              <span className="absolute -top-1 -right-1 flex h-1.5 w-1.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-pink-500"></span>
              </span>
            </div>
          )}
          <span className="text-[9px] font-bold text-gray-600">音效</span>
        </button>

        {/* Flower Cupboard / Rack Button */}
        <button 
          id="btn-collection-tab"
          onClick={() => setActiveTab('collection')}
          className="glass-panel p-2 py-2 flex flex-col items-center justify-center relative group hover:bg-white/60 active:scale-95 transition-all border-none"
          title="点击打开花库/花架"
        >
          <Basket size={18} className="text-garden-ink/70 mb-0.5" />
          <span className="text-[9px] font-bold text-gray-600">花库</span>
          {bouquetsCount > 0 && (
            <span className="absolute top-1 right-2 bg-red-500 text-white text-[8px] font-bold w-4 h-4 flex items-center justify-center rounded-full ring-1 ring-white">
              {bouquetsCount}
            </span>
          )}
        </button>

        {/* Handbook Button */}
        <button 
          id="btn-handbook-tab"
          onClick={onOpenHandbook}
          className="glass-panel p-2 py-2 flex flex-col items-center justify-center relative group hover:bg-white/60 active:scale-95 transition-all border-none"
          title="点击打开花束图鉴"
        >
          <BookOpen size={18} className="text-garden-ink/70 mb-0.5 animate-bounce-slow" />
          <span className="text-[9px] font-bold text-gray-600">图鉴</span>
        </button>

        {/* Inbox Button */}
        <button 
          id="btn-inbox-tab"
          onClick={() => setActiveTab('inbox')}
          className="glass-panel p-2 py-2 flex flex-col items-center justify-center relative group hover:bg-white/60 active:scale-95 transition-all border-none"
          title="点击打开知心信箱"
        >
          <Mail size={18} className="text-garden-ink/70 mb-0.5" />
          <span className="text-[9px] font-bold text-gray-600">信箱</span>
          {lettersCount > 0 && (
            <span className="absolute top-1 right-2 bg-blue-500 text-white text-[8px] font-bold w-4 h-4 flex items-center justify-center rounded-full ring-1 ring-white">
              {lettersCount}
            </span>
          )}
        </button>
      </div>

      {/* Weather Effects Layer */}
      <AnimatePresence>
        {weather === 'sunny' ? (
          <motion.div 
            key="sunbeam"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.5 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none overflow-hidden z-10"
          >
            {/* Soft Sunbeam / Light Leak */}
            <div 
              className="absolute -top-1/4 -left-1/4 w-[150%] h-[150%] bg-gradient-to-br from-white/40 via-white/5 to-transparent rotate-12"
              style={{ filter: 'blur(80px)' }}
            />
            {/* Dust Motes for Warmth */}
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-[2px] h-[2px] bg-white/30 rounded-full"
                animate={{
                  y: [Math.random() * 800, Math.random() * 800 - 50],
                  x: [Math.random() * 400, Math.random() * 400 + 30],
                  opacity: [0, 0.4, 0]
                }}
                transition={{
                  duration: 8 + Math.random() * 12,
                  repeat: Infinity,
                  ease: "linear"
                }}
              />
            ))}
          </motion.div>
        ) : (
          <motion.div 
            key="rain"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-10"
          >
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-[2px] h-12 bg-gradient-to-b from-blue-200/60 to-white/40"
                style={{ 
                  left: `${Math.random() * 100}%`,
                  top: -50,
                  filter: 'blur(0.5px)'
                }}
                animate={{
                  y: [-50, 950],
                  opacity: [0, 0.8, 0]
                }}
                transition={{
                  duration: 0.6 + Math.random() * 0.3,
                  repeat: Infinity,
                  delay: Math.random() * 2,
                  ease: "linear"
                }}
              />
            ))}
            {/* Additional splash/mist effect */}
            <div className="absolute inset-0 bg-white/5 backdrop-blur-[0.5px]" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Dynamic Seasonal Ambient Particle Effects */}
      <AnimatePresence mode="popLayout">
        {season === 'spring' && (
          <motion.div
            key="spring-particles"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-10 overflow-hidden"
          >
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-lg select-none"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-20px`,
                }}
                animate={{
                  y: [-20, 860],
                  x: [`0px`, `${-60 + Math.random() * 120}px`],
                  rotate: [0, 360],
                  opacity: [0, 0.8, 0.8, 0],
                }}
                transition={{
                  duration: 6 + Math.random() * 6,
                  repeat: Infinity,
                  delay: Math.random() * 8,
                  ease: "easeInOut",
                }}
              >
                🌸
              </motion.div>
            ))}
          </motion.div>
        )}
        {season === 'summer' && (
          <motion.div
            key="summer-particles"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-10 overflow-hidden"
          >
            {[...Array(15)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 rounded-full bg-yellow-250/90 shadow-[0_0_10px_#fef08a]"
                style={{
                  left: `${10 + Math.random() * 80}%`,
                  top: `${20 + Math.random() * 60}%`,
                }}
                animate={{
                  scale: [0, 1.3, 0],
                  y: [0, -100 - Math.random() * 80],
                  x: [0, -40 + Math.random() * 80],
                  opacity: [0, 0.9, 0],
                }}
                transition={{
                  duration: 4 + Math.random() * 4,
                  repeat: Infinity,
                  delay: Math.random() * 6,
                  ease: "easeInOut",
                }}
              />
            ))}
          </motion.div>
        )}
        {season === 'autumn' && (
          <motion.div
            key="autumn-particles"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-10 overflow-hidden"
          >
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-lg select-none"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-20px`,
                }}
                animate={{
                  y: [-20, 860],
                  x: [`0px`, `${-80 + Math.random() * 160}px`],
                  rotate: [0, 180 + Math.random() * 180],
                  opacity: [0, 0.82, 0.82, 0],
                }}
                transition={{
                  duration: 8 + Math.random() * 7,
                  repeat: Infinity,
                  delay: Math.random() * 8,
                  ease: "easeInOut",
                }}
              >
                🍁
              </motion.div>
            ))}
          </motion.div>
        )}
        {season === 'winter' && (
          <motion.div
            key="winter-particles"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-10 overflow-hidden"
          >
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute text-sm select-none opacity-90 text-white font-semibold"
                style={{
                  left: `${Math.random() * 100}%`,
                  top: `-20px`,
                }}
                animate={{
                  y: [-20, 860],
                  x: [`0px`, `${-30 + Math.random() * 60}px`],
                  rotate: [0, 90],
                  opacity: [0, 0.85, 0.85, 0],
                }}
                transition={{
                  duration: 5 + Math.random() * 5,
                  repeat: Infinity,
                  delay: Math.random() * 8,
                  ease: "linear",
                }}
              >
                ❄️
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Background Soft Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/20 to-transparent pointer-events-none" />
      <div className={`absolute top-0 left-0 w-full h-full opacity-30 pointer-events-none transition-opacity duration-1000 ${gameState.flowerStage === 'blooming' ? 'opacity-60' : ''}`}
        style={{ 
          background: 'radial-gradient(circle at 50% 50%, #fff 0%, transparent 70%)',
          filter: 'blur(40px)'
        }}
      />

      {/* Top Header */}
      <header className="absolute top-8 left-4 flex gap-3 items-start z-50 pointer-events-auto">
        <div className="glass-panel p-2 py-3 px-3 flex gap-3 items-center">
          <Calendar size={14} className="text-garden-ink/70" />
          <div className="text-[9px] font-mono font-medium leading-tight">
            <div>{currentTime.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })}</div>
            <div className="text-base flex items-center gap-1.5 font-bold">
              {currentTime.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </div>

        <button 
          onClick={() => {
            gardenAudio.playClickSound();
            setWeather(prev => prev === 'sunny' ? 'rainy' : 'sunny');
          }}
          className="glass-panel p-2 px-3 flex gap-4 max-h-[44px] hover:bg-white/60 active:scale-95 transition-all outline-none border-none"
        >
          <div className="flex flex-col items-center">
            {weather === 'sunny' ? <Sun size={14} className="text-orange-400 mb-0.5" /> : <CloudRain size={14} className="text-blue-400 mb-0.5" />}
            <span className="text-[8px] font-mono text-gray-500 uppercase tracking-tight">{weather === 'sunny' ? 'Sunny' : 'Rainy'}</span>
          </div>
          <div className="flex flex-col items-center">
            <Droplets size={14} className="text-blue-500 mb-0.5" />
            <span className="text-[8px] font-mono text-gray-500 uppercase tracking-tight">{weather === 'sunny' ? '45%' : '88%'}</span>
          </div>
        </button>

        <button 
          onClick={() => {
            gardenAudio.playClickSound();
            const order: ('spring' | 'summer' | 'autumn' | 'winter')[] = ['spring', 'summer', 'autumn', 'winter'];
            const currentIdx = order.indexOf(season);
            setSeason(order[(currentIdx + 1) % 4]);
          }}
          className="glass-panel p-2 px-3 flex gap-4 max-h-[44px] hover:bg-white/60 active:scale-95 transition-all outline-none border-none"
          title="点击切换季节"
        >
          <div className="flex flex-col items-center justify-center">
            <span className="text-sm leading-none mb-0.5">
              {season === 'spring' ? '🌸' :
               season === 'summer' ? '🌻' :
               season === 'autumn' ? '🍁' : '❄️'}
            </span>
            <span className="text-[8px] font-mono text-gray-500 uppercase tracking-tight">Season</span>
          </div>
          <div className="flex flex-col items-center justify-center">
            <span className="text-[10px] font-bold text-garden-ink/80 leading-none mb-0.5">
              {season === 'spring' ? '春' :
               season === 'summer' ? '夏' :
               season === 'autumn' ? '秋' : '冬'}
            </span>
            <span className="text-[8px] font-mono text-gray-500 uppercase tracking-tight">
              {season === 'spring' ? 'Spring' :
               season === 'summer' ? 'Summer' :
               season === 'autumn' ? 'Autumn' : 'Winter'}
            </span>
          </div>
        </button>
      </header>

      {/* AI Message Bubble */}
      <AnimatePresence>
        {aiMessage && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="absolute top-28 left-4 right-4 z-40"
          >
            <div className="glass-panel p-4 bg-white/90 shadow-xl relative ring-1 ring-black/5">
              <div className="absolute -top-3 left-4 bg-garden-ink text-white px-2 py-0.5 rounded-full text-[8px] font-mono font-bold flex items-center gap-1.5 uppercase tracking-widest leading-none">
                <Heart size={8} className={gameState.hatredPoints > 0 ? "text-red-500" : "text-pink-300"} />
                {currentCharacter.name}
                {gameState.hatredPoints > 0 && <span className="text-red-400 pl-1">怨念 +{gameState.hatredPoints}</span>}
              </div>
              <p className="text-[11px] leading-relaxed text-garden-ink/90 font-serif font-medium pt-1 whitespace-pre-wrap">
                {isAiThinking ? "（思考中...）" : aiMessage}
              </p>
              <div className="absolute -bottom-1.5 left-8 w-3 h-3 bg-white/90 rotate-45 border-r border-b border-white/20" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Garden Visual */}
      <main className="absolute inset-0 flex flex-col items-center justify-center pt-24">
        <div className="relative w-64 h-64 flex items-center justify-center -translate-y-24">
          {/* Pot System */}
          <div className="relative translate-y-8 scale-125 z-10">
            {/* Pot Body */}
            <div 
              className="w-40 h-36 rounded-[50%_50%_50%_50%_/_40%_40%_60%_60%] shadow-[inset_-12px_-12px_24px_rgba(0,0,0,0.15),inset_12px_12px_24px_rgba(255,255,255,0.4),0_15px_30px_rgba(0,0,0,0.1)] relative border-b-4 border-r transition-all duration-500 overflow-hidden"
              style={{ backgroundColor: currentPot.color, borderColor: currentPot.borderColor }}
            >
              <div className="absolute inset-0 opacity-10 pointer-events-none mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/natural-paper.png')]" />
            </div>

            {/* Pot Rim */}
            <div 
              className="absolute -top-3 left-1/2 -translate-x-1/2 w-[92%] h-12 rounded-[100%] border-x-4 border-b-8 shadow-sm z-20 flex items-center justify-center transition-all duration-500"
              style={{ backgroundColor: currentPot.color, borderColor: currentPot.borderColor }}
            >
              <div className="w-[88%] h-[80%] rounded-[100%] bg-[#2b1b17] shadow-[inset_0_4px_8px_rgba(0,0,0,0.8)] overflow-hidden relative">
                <div className="absolute inset-0 bg-[#3e2723] rounded-[100%] scale-110 translate-y-1 blur-[1px] opacity-80" />
              </div>
            </div>
          </div>
          
          {/* The Flower System */}
          <motion.div 
            className="absolute bottom-[104px] left-1/2 -translate-x-1/2 flex flex-col items-center z-30 pointer-events-none"
            initial={{ scale: 0, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            key={gameState.flowerType ? `${gameState.flowerType}-${gameState.flowerStage}` : 'empty'}
          >
            {gameState.flowerType && (
              <motion.div 
                className="relative flex items-center justify-center"
                animate={
                  gameState.flowerStage === 'withered' ? { opacity: [0.6, 0.4, 0.6] } :
                  gameState.flowerStage === 'seed' ? { scale: [1, 1.05, 1], rotate: [-2, 2, -2], y: [0, 2, 0] } :
                  { rotate: gameState.flowerStage === 'blooming' ? [-2, 2, -2] : [-1, 1, -1], y: [0, -4, 0] }
                }
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              >
                {gameState.flowerStage === 'seed' && (
                  <div className="relative h-10 overflow-hidden flex items-start justify-center">
                    <span className="text-7xl filter drop-shadow-xl brightness-110 translate-y-[-10%]">🫘</span>
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-12 h-4 bg-[#3e2723] rounded-full blur-[2px] opacity-90 z-40" />
                  </div>
                )}
                {gameState.flowerStage === 'sprout' && (
                  <div className="relative"><span className="text-7xl filter drop-shadow-xl brightness-110">🌱</span></div>
                )}
                {gameState.flowerStage === 'growing' && (
                  <div className="relative flex flex-col items-center">
                    <div className="w-4 h-12 bg-[#5d4037] rounded-full shadow-[inset_-2px_-2px_4px_rgba(0,0,0,0.3)] relative -mb-2">
                      <div className="absolute -left-2 top-2 text-xl">🌿</div>
                      <div className="absolute -right-2 top-4 text-xl rotate-45">🌿</div>
                    </div>
                    <span className="text-4xl filter saturate-150">🌿</span>
                  </div>
                )}
                {gameState.flowerStage === 'blooming' && (
                  <div className="relative flex flex-col items-center">
                    {/* Seasonal glowing bloom backdrop aura */}
                    <div className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full blur-3xl opacity-50 pointer-events-none transition-all duration-1000 -z-10 ${
                      season === 'spring' ? 'bg-pink-300 animate-pulse' :
                      season === 'summer' ? 'bg-amber-400 saturate-150 animate-pulse' :
                      season === 'autumn' ? 'bg-orange-500 animate-pulse' :
                      'bg-cyan-200 animate-pulse'
                    }`} />
                    {isImageAvatar(currentFlower.image) ? (
                      <motion.img 
                        src={currentFlower.image} 
                        style={{ width: '360px', height: '360px' }}
                        className="object-contain drop-shadow-2xl brightness-110 translate-y-16" 
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-6 h-20 bg-[#4e342e] rounded-t-full rounded-b-xl shadow-[inset_-4px_-4px_8px_rgba(0,0,0,0.4),0_8px_16px_rgba(0,0,0,0.2)] relative z-10 scale-x-110 mb-[-10px]">
                        <motion.div animate={{ rotate: [0, 5, 0] }} transition={{ repeat: Infinity, duration: 5 }} className="absolute -left-6 top-4 text-2xl">🌱</motion.div>
                        <motion.div animate={{ rotate: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 4, delay: 1 }} className="absolute -right-6 top-8 text-2xl rotate-45">🌱</motion.div>
                        <div className="absolute -top-12 -left-6 text-4xl filter drop-shadow-lg scale-90">{currentFlower.image}</div>
                        <div className="absolute -top-16 left-0 text-5xl filter drop-shadow-xl">{currentFlower.image}</div>
                        <div className="absolute -top-8 -right-8 text-4xl filter drop-shadow-lg scale-95">{currentFlower.image}</div>
                      </div>
                    )}
                  </div>
                )}
                {gameState.flowerStage === 'harvested' && (
                  <div className="relative pt-10">
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => setGameState(prev => ({ ...prev, flowerType: null, flowerStage: 'seed' }))}
                      className="bg-white/90 backdrop-blur-sm px-6 py-2 rounded-full shadow-lg border border-garden-ink/20 flex items-center gap-2 group pointer-events-auto"
                    >
                      <RefreshCw size={14} className="group-hover:rotate-180 transition-transform duration-500" />
                      <span className="text-[10px] font-bold uppercase tracking-widest text-garden-ink">再次播种</span>
                    </motion.button>
                  </div>
                )}
                {gameState.flowerStage === 'withered' && <span className="text-7xl filter grayscale opacity-60">🥀</span>}
                <div className="absolute -bottom-2 right-0 flex gap-1 z-50">
                  {gameState.pestLevel > 40 && <span className="text-xs animate-bounce">🐛</span>}
                  {gameState.weedsLevel > 40 && <span className="text-xs animate-bounce delay-75">🌾</span>}
                </div>
              </motion.div>
            )}

            {gameState.flowerStage === 'blooming' && (
              <motion.button 
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleHarvest}
                className="mt-6 bg-white/80 backdrop-blur-md px-6 py-2 rounded-full border-2 border-garden-ink/20 shadow-lg flex items-center gap-2 pointer-events-auto"
              >
                <Basket size={16} className="text-amber-600" />
                <span className="text-sm font-bold text-garden-ink">采摘花捧</span>
              </motion.button>
            )}
            
            {gameState.flowerType && (
              <motion.div 
                className="mt-4 px-3 py-1 bg-white/30 backdrop-blur-sm rounded-full text-[8px] font-mono font-bold tracking-widest uppercase flex items-center gap-2"
              >
                <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse" />
                {currentFlower.type} / {gameState.flowerStage}
              </motion.div>
            )}
          </motion.div>
        </div>
      </main>

      {/* Control Panel Stack */}
      <footer className="absolute bottom-6 left-4 right-4 flex flex-col gap-4 pointer-events-none">
        <div className="flex justify-end pr-2 pointer-events-auto">
          <div className="flex gap-2 items-center">
            <div className="relative group">
              <AnimatePresence>
                {!isUserActive && nudgeMessage && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.8 }}
                    className="absolute bottom-12 right-0 bg-white/90 backdrop-blur-md px-3 py-2 rounded-2xl rounded-br-none shadow-xl border border-white/50 w-32 z-50 pointer-events-none"
                  >
                    <p className="text-[10px] text-garden-ink leading-tight font-medium">{nudgeMessage}</p>
                    <div className="absolute -bottom-1 right-0 w-2 h-2 bg-white/90 rotate-45 border-r border-b border-white/20" />
                  </motion.div>
                )}
              </AnimatePresence>
              <motion.div 
                animate={{ scale: isAiThinking ? 1.1 : 1, boxShadow: isAiThinking ? '0 0 20px rgba(255, 255, 255, 0.8)' : '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                className={`w-10 h-10 rounded-full border-2 border-white overflow-hidden bg-white/40 backdrop-blur-sm transition-all duration-500 
                          ${isAiThinking ? 'opacity-100 ring-2 ring-blue-400 saturate-100' : 'opacity-60 grayscale saturate-50'}`}
              >
                {isImageAvatar(currentCharacter.avatar) ? <img src={currentCharacter.avatar} alt={currentCharacter.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center text-xl bg-white/40">{currentCharacter.avatar}</div>}
              </motion.div>
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white bg-green-400" />
            </div>
            <div className="relative group">
              {gameState.claimedBookReward && (
                <div className="absolute -inset-1.5 border border-dashed border-pink-400 rounded-full animate-spin-slow pointer-events-none z-10">
                  <div className="absolute -top-1.5 -left-1 text-[11px] select-none filter drop-shadow">🌸</div>
                  <div className="absolute -bottom-1.5 -right-1 text-[11px] select-none filter drop-shadow">🌸</div>
                  <div className="absolute -top-1.5 -right-1 text-[9px] select-none filter drop-shadow">✨</div>
                </div>
              )}
              <motion.div 
                animate={{ scale: isUserActive ? 1.1 : 1, boxShadow: isUserActive ? '0 0 20px rgba(255, 255, 255, 0.8)' : '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                className={`w-10 h-10 rounded-full border-2 border-white overflow-hidden bg-white/40 backdrop-blur-sm transition-all duration-500 ${isUserActive ? 'opacity-100 ring-2 ring-green-400 saturate-100' : 'opacity-60 grayscale saturate-50'}`}
              >
                <img src={`https://avatar.vercel.sh/${gameState.startTime}?size=64`} alt="Me" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </motion.div>
              {(gameState.walletStone || 0) > 0 && (
                <div className="absolute -bottom-2.5 -left-2 bg-gradient-to-r from-amber-400 to-yellow-500 border border-amber-100 rounded-full px-1 py-0.5 flex items-center justify-center gap-0.5 shadow-md scale-95 z-20">
                  <span className="text-[7.5px] tracking-tighter leading-none text-amber-950 font-extrabold font-mono">💎 {gameState.walletStone} 响石</span>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-x-4 gap-y-3 px-2 w-full pointer-events-auto">
          <StatBar icon={<Sprout size={12} />} label="Health" value={gameState.flowerHealth} color="bg-green-500" />
          <StatBar icon={<Droplets size={12} />} label="Water" value={gameState.waterLevel} color="bg-blue-400" />
          <StatBar icon={<Wind size={12} />} label="Soil" value={gameState.soilQuality} color="bg-amber-700" />
          <StatBar icon={<Bug size={12} />} label="Pests" value={100 - gameState.pestLevel} color="bg-purple-400" />
        </div>

        <div className="flex flex-col items-center gap-4 pointer-events-auto">
          <div className="glass-panel w-full p-2 py-4 flex justify-between items-center px-4 shadow-2xl bg-white/70">
            <ToolButton icon={<Shovel size={20} />} label="翻土" onClick={() => handleAction('soil')} disabled={gameState.flowerStage === 'withered'} />
            <ToolButton icon={<Droplets size={20} />} label="浇水" onClick={() => handleAction('water')} disabled={gameState.flowerStage === 'withered'} />
            <ToolButton icon={<Bug size={20} />} label="除虫" onClick={() => handleAction('pest')} disabled={gameState.flowerStage === 'withered'} />
            <ToolButton icon={<Trash2 size={20} />} label="除草" onClick={() => handleAction('weed')} disabled={gameState.flowerStage === 'withered'} />
            <ToolButton icon={<FlaskConical size={20} />} label="瓶" onClick={() => handleAction('nutrient')} disabled={gameState.flowerStage === 'withered'} />
          </div>
          <button onClick={handleReset} className="text-[9px] font-bold text-red-400 uppercase tracking-widest p-2 opacity-50 hover:opacity-100 transition-opacity">Reset Garden</button>
        </div>
      </footer>
    </div>
  );
};

const BasketView = ({ bouquets, selectedIndices, onToggleSelect, onClose, onGift, onOpenBundle, unlockedFlowers = [], onOpenHandbook }: { bouquets: FlowerType[], selectedIndices: number[], onToggleSelect: (i: number) => void, onClose: () => void, onGift: (i: number) => void, onOpenBundle: () => void, unlockedFlowers: FlowerType[], onOpenHandbook: () => void }) => (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} className="absolute inset-0 bg-garden-bg z-[100] flex flex-col p-6 overflow-hidden">
    <div className="flex justify-between items-center mb-6 shrink-0">
      <div>
        <h2 className="text-xl font-serif font-bold flex items-center gap-2"><Basket className="text-amber-600" /> 采摘篮</h2>
        <div className="mt-3 space-y-2">
          <div className="p-3 rounded-xl bg-gradient-to-br from-pink-50 to-amber-50 border border-pink-100/30 shadow-inner">
            <p className="text-[10px] text-gray-600 leading-relaxed">
              每朵赠予的花都能为 TA 带来 +3 好感度。<br />
              尝试将三朵鲜花包扎成簇，附上定制贺卡寄出，还能收到 TA的心意回信。
            </p>
          </div>
          <p className="text-[10px] font-bold bg-gradient-to-r from-pink-500 to-amber-600 bg-clip-text text-transparent ml-1">
            ※请不要将你们合力灌溉的心意送给旁人。
          </p>
        </div>
      </div>
      <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full shrink-0 self-start"><X size={24} /></button>
    </div>
    
    <div className="flex-1 overflow-y-auto pr-1 pb-32">
      <div className="grid grid-cols-2 gap-4">
        {bouquets.length === 0 ? (
          <div className="col-span-2 text-center py-20 text-gray-400">
            <Flower size={48} className="mx-auto mb-4 opacity-10" />
            <p className="text-sm">篮子里还是空的，去养花吧。</p>
          </div>
        ) : (
          bouquets.map((b, i) => {
            const flower = FLOWERS.find(f => f.type === b)!;
            const isSelected = selectedIndices.includes(i);
            return (
              <div 
                key={i} 
                onClick={() => onToggleSelect(i)}
                className={`p-4 rounded-3xl flex flex-col items-center gap-3 shadow-sm transition-all cursor-pointer border-2 relative
                  ${isSelected ? 'bg-garden-ink text-white border-garden-ink scale-[1.02]' : 'bg-white border-transparent'}`}
              >
                {isSelected && (
                  <div className="absolute top-2 right-2 bg-white text-garden-ink rounded-full p-0.5">
                    <div className="w-4 h-4 rounded-full bg-garden-ink flex items-center justify-center text-[10px] text-white font-bold">✓</div>
                  </div>
                )}
                <div className="w-16 h-16 flex items-center justify-center">
                  {isImageAvatar(flower.image) ? <img src={flower.image} className="w-full h-full object-contain" /> : <span className="text-4xl">{flower.image}</span>}
                </div>
                <span className={`text-[10px] font-bold tracking-widest uppercase ${isSelected ? 'text-white' : ''}`}>{b}</span>
                <button 
                  onClick={(e) => { e.stopPropagation(); onGift(i); }}
                  className={`w-full py-2 rounded-full text-[10px] font-bold uppercase tracking-widest hover:scale-105 transition-transform flex items-center justify-center gap-2
                    ${isSelected ? 'bg-white text-garden-ink' : 'bg-garden-ink text-white'}`}
                >
                  <Gift size={12} /> 直接送
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>

    {/* Fixed Book Button - Bottom Left (Inside 380x844 relative bounds) */}
    <div className="absolute bottom-6 left-6 z-[110]">
      <button 
        onClick={onOpenHandbook}
        className="w-24 h-24 rounded-full shadow-2xl flex flex-col items-center justify-center bg-white hover:scale-110 active:scale-95 transition-all text-pink-600 border border-pink-100 relative overflow-hidden group"
      >
        <span className="text-3xl filter drop-shadow group-hover:scale-110 transition-transform">📖</span>
        <span className="text-[10px] font-bold mt-1 tracking-tight text-pink-600">
          花卉图鉴
        </span>
        <div className="absolute -top-1 -right-1 bg-gradient-to-r from-pink-500 to-rose-500 text-white text-[8px] font-mono px-2 py-1 rounded-full scale-90 origin-top-right shadow-sm font-bold">
          {unlockedFlowers.length}/9
        </div>
      </button>
    </div>

    {/* Fixed Bundle Button - Bottom Right (Inside 380x844 relative bounds) */}
    <div className="absolute bottom-6 right-6 z-[110]">
      <button 
        disabled={selectedIndices.length !== 3}
        onClick={onOpenBundle}
        className={`w-24 h-24 rounded-full shadow-2xl flex flex-col items-center justify-center transition-all duration-500 overflow-hidden relative group
          ${selectedIndices.length === 3 
            ? 'bg-gradient-to-br from-pink-500 via-rose-500 to-amber-500 scale-100 hover:scale-110 active:scale-95 text-white' 
            : 'bg-white/40 backdrop-blur-md border-2 border-dashed border-garden-ink/10 opacity-30 grayscale cursor-not-allowed text-garden-ink'}`}
      >
        <Flower2 size={selectedIndices.length === 3 ? 40 : 32} className={`transition-all duration-500 ${selectedIndices.length === 3 ? 'drop-shadow-lg rotate-12' : ''}`} />
        <span className={`text-[9px] font-bold mt-1 tracking-tighter uppercase transition-opacity ${selectedIndices.length === 3 ? 'opacity-100' : 'opacity-40'}`}>
          {selectedIndices.length === 3 ? '定制花束' : `${selectedIndices.length}/3`}
        </span>
        
        {/* Decorative sparkles for ready state */}
        {selectedIndices.length === 3 && (
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 8, ease: "linear" }}
            className="absolute inset-0 pointer-events-none opacity-20 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]"
          />
        )}
      </button>
    </div>
  </motion.div>
);


const BundleBouquetModal = ({ selectedFlowers, onClose, onGift }: { selectedFlowers: FlowerType[], onClose: () => void, onGift: (targetIds: string[], cardMessage: string) => void }) => {
  const [selectedCharIds, setSelectedCharIds] = useState<string[]>([]);
  const [cardMessage, setCardMessage] = useState<string>('');

  const handleToggleChar = (id: string) => {
    setSelectedCharIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/40 backdrop-blur-sm z-[150] flex flex-col justify-end p-4 pointer-events-auto">
      <motion.div initial={{ y: 100 }} animate={{ y: 0 }} className="bg-white rounded-[40px] p-8 pb-12 max-h-[90%] flex flex-col shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-xl font-serif font-bold">定制你的花束</h3>
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Bundle x3: {selectedFlowers.join(' + ')}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full"><X size={24} /></button>
        </div>

        <div className="flex-1 overflow-y-auto pr-2 space-y-8">
          {/* Card Message */}
          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-garden-ink/40 mb-3 ml-1">贺卡留言</h4>
            <textarea 
              value={cardMessage}
              onChange={(e) => setCardMessage(e.target.value)}
              placeholder="在这里留下你的秘密私语..."
              className="w-full bg-garden-bg rounded-2xl p-4 text-sm font-serif outline-none border-2 border-transparent focus:border-amber-200 transition-all h-24 resize-none"
            />
          </div>

          {/* Character Selection */}
          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-garden-ink/40 mb-3 ml-1">选择接收者 (可多选)</h4>
            <div className="flex flex-col gap-2">
              {CHARACTERS.map(c => {
                const isSelected = selectedCharIds.includes(c.id);
                return (
                  <button 
                    key={c.id} 
                    onClick={() => handleToggleChar(c.id)}
                    className={`p-4 rounded-2xl flex items-center gap-4 transition-all border-2
                      ${isSelected ? 'bg-amber-50 border-amber-500 scale-[1.02]' : 'bg-garden-bg border-transparent'}`}
                  >
                    <div className="w-10 h-10 rounded-full border-2 border-white overflow-hidden shrink-0">
                      {isImageAvatar(c.avatar) ? <img src={c.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-white text-lg">{c.avatar}</div>}
                    </div>
                    <div className="text-left font-bold text-sm">{c.name}</div>
                    {isSelected && <div className="ml-auto w-5 h-5 bg-amber-500 rounded-full flex items-center justify-center text-white text-[10px]">✓</div>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        <button 
          disabled={selectedCharIds.length === 0}
          onClick={() => onGift(selectedCharIds, cardMessage)}
          className={`mt-8 w-full py-4 rounded-full font-serif font-bold text-lg shadow-xl transition-all
            ${selectedCharIds.length > 0 ? 'bg-garden-ink text-white hover:scale-[1.02]' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
        >
          寄出花束
        </button>
      </motion.div>
    </motion.div>
  );
};

const InboxView = ({ letters, onClose, onSelectLetter, selectedLetter }: { letters: Letter[], onClose: () => void, onSelectLetter: (l: Letter) => void, selectedLetter: Letter | null }) => (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }} className="absolute inset-0 bg-garden-bg z-[100] flex flex-col p-6 overflow-y-auto">
    <div className="flex justify-between items-center mb-8">
      <h2 className="text-xl font-serif font-bold flex items-center gap-2"><Mail className="text-blue-500" /> 秘密信条</h2>
      <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full"><X size={24} /></button>
    </div>
    <div className="flex flex-col gap-3">
      {letters.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <Mail size={48} className="mx-auto mb-4 opacity-10" />
            <p className="text-sm">还没有收到过任何回信。</p>
          </div>
        ) : (
          letters.map((l) => (
            <button 
              key={l.id} 
              onClick={() => onSelectLetter(l)}
              className={`p-4 rounded-2xl text-left transition-all ${l.isJealous ? 'bg-red-50 border-red-100 border' : 'bg-white shadow-sm'}`}
            >
              <div className="flex justify-between items-center mb-1">
                <span className="font-bold text-sm flex items-center gap-2">
                  {l.fromName} {l.isJealous && <Heart size={10} className="text-red-500 fill-red-500" />}
                </span>
                <span className="text-[9px] font-mono opacity-40">{new Date(l.time).toLocaleDateString()}</span>
              </div>
              <p className="text-xs text-gray-500 line-clamp-1">{l.content}</p>
            </button>
          ))
        )}
    </div>
    <AnimatePresence>
      {selectedLetter && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="fixed inset-4 bg-white z-[110] rounded-3xl shadow-2xl p-8 flex flex-col">
          <div className="flex justify-between items-start mb-6">
            <div className="bg-garden-ink text-white px-2 py-0.5 rounded-full text-[10px] font-mono font-bold tracking-widest uppercase">
              From: {selectedLetter.fromName}
            </div>
            <button onClick={() => onSelectLetter(null as any)} className="p-1 hover:bg-black/5 rounded-full"><X size={20} /></button>
          </div>
          <p className="text-sm leading-relaxed font-serif whitespace-pre-wrap flex-1 overflow-y-auto pr-2">
            {selectedLetter.content}
          </p>
          <div className="pt-6 border-t font-mono text-[10px] text-gray-400 italic">
            -- {new Date(selectedLetter.time).toLocaleString()}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  </motion.div>
);

const GiftModal = ({ flowerType, onClose, onGift }: { flowerType: string, onClose: () => void, onGift: (id: string) => void }) => (
  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="absolute inset-0 bg-black/40 backdrop-blur-sm z-[150] flex flex-col justify-end p-4">
    <motion.div initial={{ y: 100 }} animate={{ y: 0 }} className="bg-white rounded-[40px] p-8 pb-12 max-h-[80%] flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-lg font-serif font-bold">要送给谁呢？</h3>
          <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">Present Bouquet: {flowerType}</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-black/5 rounded-full"><X size={24} /></button>
      </div>
      <div className="flex flex-col gap-3 overflow-y-auto">
        {CHARACTERS.map(c => (
          <button 
            key={c.id} 
            onClick={() => onGift(c.id)}
            className="p-4 bg-garden-bg rounded-2xl flex items-center gap-4 hover:scale-[1.02] active:scale-95 transition-all group"
          >
            <div className="w-12 h-12 rounded-full border-2 border-white overflow-hidden group-hover:rotate-6 transition-transform">
              {isImageAvatar(c.avatar) ? <img src={c.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center bg-white text-2xl">{c.avatar}</div>}
            </div>
            <div className="text-left font-bold">{c.name}</div>
            <Gift size={16} className="ml-auto text-pink-400 opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        ))}
      </div>
    </motion.div>
  </motion.div>
);

function StatBar({ icon, label, value, color }: { icon: React.ReactNode, label: string, value: number, color: string }) {
  return (
    <div className="flex items-center gap-3 w-40">
      <div className="text-garden-ink/60">{icon}</div>
      <div className="flex-1">
        <div className="flex justify-between text-[10px] font-mono font-bold mb-1 opacity-60">
          <span>{label}</span>
          <span>{value}%</span>
        </div>
        <div className="h-1.5 w-full bg-black/5 rounded-full overflow-hidden">
          <motion.div 
            className={`h-full ${color}`}
            initial={{ width: 0 }}
            animate={{ width: `${value}%` }}
          />
        </div>
      </div>
    </div>
  );
}

function ToolButton({ icon, label, onClick, disabled }: { icon: React.ReactNode, label: string, onClick: () => void, disabled?: boolean }) {
  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`flex flex-col items-center gap-1.5 p-4 rounded-2xl transition-all active:scale-95
        ${disabled ? 'opacity-30 grayscale cursor-not-allowed' : 'hover:bg-white hover:shadow-lg text-garden-ink'}`}
    >
      <div className="transition-transform group-hover:-translate-y-1">
        {icon}
      </div>
      <span className="text-[10px] font-bold tracking-widest uppercase">{label}</span>
    </button>
  );
}

const HandbookModal = ({ 
  gameState, 
  setGameState, 
  onClose 
}: { 
  gameState: GameState, 
  setGameState: React.Dispatch<React.SetStateAction<GameState>>, 
  onClose: () => void 
}) => {
  const [tab, setTab] = useState<'premium' | 'individual'>('premium');

  const unlockedFlowers = gameState.unlockedFlowers || [];
  const completedBouquets = gameState.completedPremiumBouquets || [];

  // Compute actual count of harvested flowers in the player's cupboard (inventory)
  const inventoryCounts: { [key: string]: number } = {};
  gameState.bouquets.forEach(bt => {
    inventoryCounts[bt] = (inventoryCounts[bt] || 0) + 1;
  });

  // Check if a specific premium bouquet can be crafted right now
  const checkCanCraft = (formula: { [key: string]: number }) => {
    for (const [flower, requiredCount] of Object.entries(formula)) {
      if ((inventoryCounts[flower] || 0) < requiredCount) {
        return false;
      }
    }
    return true;
  };

  // Synthesis action to craft a premium bouquet
  const handleCraft = (id: string, name: string, formula: { [key: string]: number }) => {
    // Play synthesis celebratory fanfare sound!
    gardenAudio.playBloomFanfare();

    setGameState(prev => {
      const remainingBouquets = [...prev.bouquets];
      
      // Remove required ingredient flowers
      for (const [flower, countNeeded] of Object.entries(formula)) {
        let removed = 0;
        while (removed < countNeeded) {
          const idx = remainingBouquets.indexOf(flower as FlowerType);
          if (idx !== -1) {
            remainingBouquets.splice(idx, 1);
            removed++;
          } else {
            break;
          }
        }
      }

      const prevCompleted = prev.completedPremiumBouquets || [];
      const updatedCompleted = prevCompleted.includes(id) 
        ? prevCompleted 
        : [...prevCompleted, id];

      const updatedHistory: GameEvent[] = [
        {
          time: Date.now(),
          type: 'gift',
          description: `🎉 成功配方研制，合成了组合高级花束：【${name}】！花费了花材原料。`
        },
        ...prev.history
      ];

      const updatedState = {
        ...prev,
        bouquets: remainingBouquets,
        completedPremiumBouquets: updatedCompleted,
        history: updatedHistory
      };

      // Save to localStorage immediately
      localStorage.setItem('flower_game_state', JSON.stringify(updatedState));
      return updatedState;
    });
  };

  // Claim grand reward action
  const handleClaimReward = () => {
    if (completedBouquets.length < 6 || gameState.claimedBookReward) return;

    // Play synthesis celebratory fanfare sound twice for premium feedback!
    gardenAudio.playBloomFanfare();

    setGameState(prev => {
      const updatedState = {
        ...prev,
        claimedBookReward: true,
        walletStone: (prev.walletStone || 0) + 200,
        unlockedFrames: [...(prev.unlockedFrames || []), 'flower_frame'],
        history: [
          {
            time: Date.now(),
            type: 'nutrient',
            description: `🎁 领取了手捧鲜花图鉴大奖！获得了 200 响石和专属「花卉头像框」！`
          },
          ...prev.history
        ]
      };
      localStorage.setItem('flower_game_state', JSON.stringify(updatedState));
      return updatedState;
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }} 
      exit={{ opacity: 0 }} 
      className="absolute inset-0 bg-black/70 backdrop-blur-sm z-[160] flex flex-col justify-end p-4 pointer-events-auto select-none"
    >
      <motion.div 
        initial={{ y: "100%" }} 
        animate={{ y: 0 }} 
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 350 }}
        className="bg-stone-50 rounded-[40px] p-5 pb-8 max-h-[94%] flex flex-col shadow-2xl relative border border-white/20"
      >
        {/* Header Tabs Controls */}
        <div className="flex justify-between items-center mb-2.5 shrink-0">
          <div className="flex gap-2 p-1 bg-black/5 rounded-2xl">
            <button
              onClick={() => setTab('premium')}
              className={`px-4 py-1.5 rounded-xl font-serif text-[11px] font-bold tracking-wider transition-all duration-300 ${
                tab === 'premium' ? 'bg-white text-pink-600 shadow-sm scale-105' : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              💖 组合花束 ({completedBouquets.length} / 6)
            </button>
            <button
              onClick={() => setTab('individual')}
              className={`px-4 py-1.5 rounded-xl font-serif text-[11px] font-bold tracking-wider transition-all duration-300 ${
                tab === 'individual' ? 'bg-white text-blue-600 shadow-sm scale-105' : 'text-gray-500 hover:text-gray-900'
              }`}
            >
              🌿 单花奇珍 ({unlockedFlowers.length} / {FLOWERS.length})
            </button>
          </div>
          <button 
            onClick={onClose} 
            className="p-1.5 hover:bg-black/5 rounded-full text-stone-500 transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {tab === 'premium' ? (
          /* Premium Bouquet Combination handbook */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Top Banner and Titles */}
            <div className="text-center py-2 shrink-0 bg-white/40 rounded-3xl border border-white/40 px-3 mb-3 shadow-inner">
              <h3 className="text-lg font-serif font-black bg-gradient-to-r from-pink-600 via-rose-500 to-amber-600 bg-clip-text text-transparent leading-normal tracking-wide">
                总有人一直手捧鲜花为你而来
              </h3>
              <p className="text-[9.5px] text-amber-800 font-bold tracking-tight mt-1">
                ✨ 收集花束图鉴可以解锁 <span className="text-rose-500">200响石</span> 领取和 <span className="text-pink-600">花卉头像框</span>
              </p>
            </div>

            {/* Claim Grand Prize Panel */}
            <div className="mb-3 p-3 rounded-2xl bg-gradient-to-r from-pink-50/70 via-amber-50/70 to-pink-50/70 border border-white shrink-0 flex items-center justify-between shadow-sm relative overflow-hidden">
              <div className="absolute -right-3 -top-3 text-pink-200/10 rotate-12 text-5xl">🎁</div>
              <div className="min-w-0 pr-2">
                <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block">图鉴收集进度</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-xs font-black font-mono text-pink-600">{completedBouquets.length} / 6</span>
                  <div className="w-24 h-1.5 bg-black/5 rounded-full overflow-hidden border border-black/5">
                    <div 
                      className="h-full bg-gradient-to-r from-pink-400 to-amber-500 rounded-full transition-all duration-500" 
                      style={{ width: `${(completedBouquets.length / 6) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              {gameState.claimedBookReward ? (
                <div className="bg-emerald-50 text-emerald-700 text-[10px] px-2.5 py-1.5 rounded-xl border border-emerald-100 flex items-center gap-1 font-bold">
                  <span>✅ 已兑换头像框与200响石</span>
                </div>
              ) : completedBouquets.length === 6 ? (
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleClaimReward}
                  className="bg-gradient-to-r from-amber-400 to-rose-500 text-white font-bold text-[10px] px-3.5 py-2 rounded-xl flex items-center gap-1 shadow-[0_4px_12px_rgba(251,113,133,0.3)] animate-pulse"
                >
                  <Sparkles size={11} /> 领取大奖
                </motion.button>
              ) : (
                <button
                  disabled
                  className="bg-gray-200 text-gray-400 font-bold text-[10px] px-3.5 py-2 rounded-xl cursor-not-allowed"
                >
                  集齐可点亮大奖
                </button>
              )}
            </div>

            {/* List scroll container */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-3 pb-2 scrollbar-none">
              <div className="grid grid-cols-1 gap-3">
                {PREMIUM_BOUQUETS.map((b) => {
                  const isCompleted = completedBouquets.includes(b.id);
                  const canCraft = !isCompleted && checkCanCraft(b.formula);

                  if (isCompleted) {
                    /* Completed state: "亮着的已制作完的高级花束，不显示按钮，纯展示（卡片消失保留花束），有轻微动效" */
                    return (
                      <motion.div 
                        key={b.id}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="p-4 rounded-[28px] bg-transparent border-none text-center relative flex flex-col items-center justify-center overflow-hidden py-6"
                      >
                        {/* Glow effect */}
                        <div className="absolute inset-0 bg-radial-glow opacity-25 -z-10 animate-pulse pointer-events-none" />
                        
                        <motion.div
                          animate={{ 
                            y: [0, -6, 0],
                            rotate: [0, 1.5, -1.5, 0]
                          }}
                          transition={{
                            duration: 4,
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className="relative flex flex-col items-center cursor-default group"
                        >
                          <div className="absolute -inset-4 bg-pink-100/30 blur-2xl rounded-full scale-110 opacity-60 z-0 animate-ping-slow" />
                          <div className="text-6xl drop-shadow-[0_8px_16px_rgba(244,63,94,0.15)] select-none relative z-10 transition-transform group-hover:scale-110 duration-500">
                            💐
                          </div>
                          <div className="absolute -top-1 -right-2 text-xl select-none animate-bounce z-20">✨</div>
                        </motion.div>

                        <div className="mt-3.5 relative z-10">
                          <h4 className="font-serif font-black text-rose-800 text-base drop-shadow-sm flex items-center justify-center gap-1">
                            {b.name}
                          </h4>
                          <p className="text-[10px] text-pink-700/80 font-medium max-w-xs mt-1 leading-relaxed">
                            {b.description}
                          </p>
                          <div className="inline-flex items-center gap-1 bg-pink-100 border border-pink-200 text-pink-700 text-[8px] font-bold rounded-full px-2.5 py-0.5 mt-2.5 shadow-sm">
                            🏅 已收纳高级花展
                          </div>
                        </div>
                      </motion.div>
                    );
                  }

                  // Non-Completed States ("无法制作" 或 "待制作")
                  return (
                    <div 
                      key={b.id}
                      className={`p-3.5 rounded-[24px] border transition-all duration-300 flex flex-col gap-3 relative overflow-hidden ${
                        canCraft 
                          ? 'bg-gradient-to-br from-pink-50/40 to-white border-pink-100 shadow-[0_2px_12px_rgba(244,63,94,0.03)]' 
                          : 'bg-stone-100/80 border-stone-200/50 grayscale opacity-80'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        {/* Bouquet Icon */}
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border relative ${
                          canCraft ? 'bg-pink-100/30 border-pink-150' : 'bg-stone-200 border-stone-300 shadow-inner'
                        }`}>
                          <span className="text-3xl select-none filter drop-shadow-sm">💐</span>
                          <span className="absolute -bottom-1 -right-1 text-sm">{b.emoji}</span>
                        </div>

                        {/* Title and descriptions */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <h4 className="font-serif font-bold text-xs text-stone-850 truncate">{b.name}</h4>
                            <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${
                              canCraft ? 'bg-green-150 text-green-700 animate-pulse' : 'bg-stone-200 text-stone-500'
                            }`}>
                              {canCraft ? '待制作' : '无法制作'}
                            </span>
                          </div>
                          <p className="text-[9.5px] leading-relaxed text-stone-600 mt-1 line-clamp-2">
                            {b.description}
                          </p>
                        </div>
                      </div>

                      {/* Formula Materials list */}
                      <div className="p-2 bg-stone-50 border border-stone-100 rounded-xl">
                        <span className="text-[8px] font-bold text-stone-400 uppercase tracking-widest block mb-1.5 font-mono">
                          📖 组合材料配方清单
                        </span>
                        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                          {Object.entries(b.formula).map(([fType, rem]) => {
                            const have = inventoryCounts[fType] || 0;
                            const isMet = have >= rem;
                            return (
                              <div key={fType} className="flex justify-between items-center text-[9px] font-mono">
                                <span className={`flex items-center gap-1 ${isMet ? 'text-stone-700' : 'text-stone-400 font-normal'}`}>
                                  {isMet ? '✅' : '❌'} {fType}
                                </span>
                                <span className={isMet ? 'text-green-600 font-bold' : 'text-rose-500 font-bold'}>
                                  {have} / {rem}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                      {/* Synthesis Button */}
                      {canCraft ? (
                        <motion.button
                          whileHover={{ scale: 1.01 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleCraft(b.id, b.name, b.formula)}
                          className="w-full py-2 bg-gradient-to-r from-pink-400 to-rose-500 hover:from-pink-500 hover:to-rose-600 text-white font-bold text-[10.5px] rounded-xl flex items-center justify-center gap-1.5 shadow-[0_2px_8px_rgba(244,63,94,0.15)] cursor-pointer"
                        >
                          💖 合成配方花束 【{b.name}】
                        </motion.button>
                      ) : (
                        <button
                          disabled
                          className="w-full py-2 bg-stone-200 text-stone-450 font-bold text-[10px] rounded-xl cursor-not-allowed"
                        >
                          无法制作 (材料不足)
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          /* Individual single flowers dictionary (Existing code but expanded to include all 14 flowers) */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Header progress bar */}
            <div className="mb-3">
              <p className="text-[10px] text-blue-600 font-bold tracking-widest uppercase font-mono mb-1.5">
                花卉繁育图鉴解锁：{unlockedFlowers.length} / {FLOWERS.length}
              </p>
              <div className="w-full h-1.5 bg-blue-50 rounded-full overflow-hidden border border-blue-150">
                <motion.div 
                  className="h-full bg-gradient-to-r from-blue-400 to-indigo-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(unlockedFlowers.length / FLOWERS.length) * 100}%` }}
                />
              </div>
            </div>

            {/* Flowers Grid scroll area */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-3 pb-2 scrollbar-none">
              <div className="grid grid-cols-1 gap-3">
                {FLOWERS.map((f) => {
                  const isUnlocked = unlockedFlowers.includes(f.type);
                  return (
                    <div 
                      key={f.type}
                      className={`p-3.5 rounded-[24px] border transition-all duration-300 flex items-start gap-3.5 relative overflow-hidden
                        ${isUnlocked 
                          ? 'bg-gradient-to-br from-blue-50/30 via-white to-indigo-50/10 border-blue-100 shadow-inner-white' 
                          : 'bg-stone-100 border-stone-200/55 grayscale opacity-75'}`}
                    >
                      {/* Locks watermark */}
                      {isUnlocked ? (
                        <div className="absolute -right-3 -bottom-3 text-blue-500/5 rotate-12 text-6xl select-none pointer-events-none">✨</div>
                      ) : (
                        <div className="absolute right-3.5 top-3.5 text-stone-300 select-none pointer-events-none">
                          <Lock size={12} className="opacity-40" />
                        </div>
                      )}

                      {/* Icon */}
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border transition-all duration-500
                        ${isUnlocked 
                          ? 'bg-white border-blue-100 shadow-sm' 
                          : 'bg-stone-200/60 border-stone-300 shadow-none'}`}
                      >
                        {isUnlocked ? (
                          isImageAvatar(f.image) ? (
                            <img src={f.image} className="w-10 h-10 object-contain" />
                          ) : (
                            <span className="text-3.5xl filter drop-shadow-sm">{f.image}</span>
                          )
                        ) : (
                          <span className="text-2xl opacity-25 filter blur-[0.5px]">❓</span>
                        )}
                      </div>

                      {/* Text */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4 className={`font-serif font-black text-[11.5px] ${isUnlocked ? 'text-stone-850' : 'text-stone-400'}`}>
                            {isUnlocked ? f.name : '未知稀有花卉'}
                          </h4>
                          <span className={`text-[7.5px] px-1.5 py-0.5 rounded-full font-mono font-bold
                            ${isUnlocked 
                              ? 'bg-blue-100 text-blue-700' 
                              : 'bg-stone-200 text-stone-400'}`}
                          >
                            {isUnlocked ? '已点亮' : '未解锁'}
                          </span>
                        </div>

                        <p className={`text-[9.5px] leading-relaxed mt-1 line-clamp-2 ${isUnlocked ? 'text-stone-650' : 'text-stone-400'}`}>
                          {isUnlocked ? f.description : '尚未完成繁育成长。陪伴 TA 细心灌溉到 blooming 阶段收获即可永久录入。'}
                        </p>

                        {/* Language */}
                        <div className={`mt-2 p-1.5 rounded-xl text-[9.5px] leading-relaxed transition-all
                          ${isUnlocked 
                            ? 'bg-blue-50/50 border border-blue-100/40 text-blue-800' 
                            : 'bg-stone-200/50 text-stone-400 border border-transparent'}`}
                        >
                          <span className="font-bold flex items-center gap-1">
                            {isUnlocked ? '✨ 花语：' : '🔒 封存：'}
                            <span className={isUnlocked ? 'font-medium text-stone-700' : 'font-normal italic'}>
                              {isUnlocked ? f.language : '尚未窥见花语细节。种出后自动解锁。'}
                            </span>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

const WitheringNoticeModal = ({
  onClose,
  dontShowAgainChecked,
  setDontShowAgainChecked
}: {
  onClose: () => void;
  dontShowAgainChecked: boolean;
  setDontShowAgainChecked: (val: boolean) => void;
}) => (
  <motion.div 
    initial={{ opacity: 0 }} 
    animate={{ opacity: 1 }} 
    exit={{ opacity: 0 }} 
    className="absolute inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-6 pointer-events-auto select-none"
  >
    <motion.div 
      initial={{ scale: 0.9, y: 20 }} 
      animate={{ scale: 1, y: 0 }} 
      exit={{ scale: 0.9, y: 20 }}
      transition={{ type: "spring", damping: 25, stiffness: 350 }}
      className="bg-white rounded-[32px] p-6 max-w-sm w-full shadow-2xl relative border border-amber-100/50 flex flex-col"
    >
      {/* Icon representation */}
      <div className="flex flex-col items-center text-center mb-4 mt-2">
        <div className="w-14 h-14 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center text-3xl mb-3 shadow-inner animate-pulse">
          🛡️
        </div>
        <h3 className="text-lg font-serif font-black text-amber-900 flex items-center gap-1.5 justify-center">
          养花小卫士
        </h3>
        <div className="w-12 h-1 bg-amber-200/50 rounded-full mt-1.5" />
      </div>

      <p className="text-[12px] leading-relaxed text-stone-650 text-center mb-6 px-1">
        超过 <span className="text-rose-500 font-bold">3 天</span>未浇水，花朵会枯萎哦～枯萎后 <span className="text-amber-600 font-bold">5 天内</span>未抢救，AI 怨念值 <span className="text-rose-600 font-bold font-mono">+1</span>，花朵将重置为种子重新种植.
      </p>

      {/* Footer controls */}
      <div className="flex items-center justify-between mt-2 pt-3 border-t border-stone-100">
        {/* Checkbox on left bottom */}
        <label className="flex items-center gap-2 cursor-pointer select-none">
          <input 
            type="checkbox" 
            checked={dontShowAgainChecked} 
            onChange={(e) => {
              gardenAudio.playClickSound();
              setDontShowAgainChecked(e.target.checked);
            }} 
            className="w-4 h-4 rounded border-stone-300 text-amber-600 focus:ring-amber-500 accent-amber-500 cursor-pointer"
          />
          <span className="text-[11px] text-stone-500 font-medium select-none font-sans">不再提醒</span>
        </label>

        {/* Got it on center-right */}
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={onClose}
          className="bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-605 text-stone-900 font-bold text-[11px] px-6 py-2 rounded-xl shadow-[0_3px_8px_rgba(245,158,11,0.2)] cursor-pointer font-sans"
        >
          知道了
        </motion.button>
      </div>
    </motion.div>
  </motion.div>
);

const OfflineLogModal = ({
  offlineLog,
  onClose
}: {
  offlineLog: {
    timeAwayStr: string;
    events: { timeStr: string; type: 'weather' | 'companion' | 'flower' | 'general'; desc: string; icon: string }[];
  };
  onClose: () => void;
}) => (
  <motion.div 
    initial={{ opacity: 0 }} 
    animate={{ opacity: 1 }} 
    exit={{ opacity: 0 }} 
    className="absolute inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-6 pointer-events-auto select-none"
  >
    <motion.div 
      initial={{ scale: 0.9, y: 20 }} 
      animate={{ scale: 1, y: 0 }} 
      exit={{ scale: 0.9, y: 20 }}
      transition={{ type: "spring", damping: 25, stiffness: 350 }}
      className="bg-stone-50 rounded-[32px] p-6 max-w-md w-full max-h-[85vh] overflow-hidden shadow-2xl relative border border-stone-200/50 flex flex-col"
    >
      {/* Header */}
      <div className="flex flex-col items-center text-center mb-4 mt-1 shrink-0">
        <div className="w-12 h-12 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-2xl mb-2.5 shadow-inner">
          📜
        </div>
        <h3 className="text-base font-serif font-black text-emerald-900 leading-tight">
          离线守候日志
        </h3>
        <p className="text-[11px] text-stone-500 mt-1.5 leading-normal px-2">
          在你离开的 <span className="font-semibold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md font-mono">{offlineLog.timeAwayStr}</span> 内，陪伴你的 AI 伙伴将花园打理得很细致，发生了以下变化：
        </p>
      </div>

      {/* Timeline Section */}
      <div className="flex-1 overflow-y-auto pr-1 my-3 space-y-4 max-h-[45vh] scrollbar-thin">
        <div className="relative border-l ml-4 pl-6 space-y-6 py-2 border-emerald-200/80">
          {offlineLog.events.map((evt, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: idx * 0.15 }}
              className="relative"
            >
              {/* Node Bullet and Icon */}
              <span className="absolute -left-[37px] top-0.5 flex items-center justify-center w-7 h-7 bg-white rounded-full border border-emerald-100 shadow-sm text-sm z-10">
                {evt.icon}
              </span>
              
              {/* Event payload */}
              <div className="flex flex-col">
                <span className="text-[10px] uppercase font-mono font-bold text-stone-400 tracking-wider">
                  {evt.timeStr}
                </span>
                <p className="text-[11px] leading-relaxed text-stone-700 mt-1 bg-white p-2.5 rounded-2xl border border-stone-200/45 shadow-sm font-sans select-text">
                  {evt.desc}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Close button */}
      <div className="shrink-0 pt-3.5 border-t border-stone-200/60 flex justify-end mt-2">
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          onClick={onClose}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[11px] tracking-wide px-8 py-2.5 rounded-xl cursor-pointer font-sans shadow-[0_3px_8px_rgba(16,185,129,0.15)]"
        >
          查看花园
        </motion.button>
      </div>
    </motion.div>
  </motion.div>
);
